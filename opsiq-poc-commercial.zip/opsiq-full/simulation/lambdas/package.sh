#!/usr/bin/env bash
# OpsIQ simulation Lambda packager — Windows Git Bash / Amazon WorkSpaces
set -euo pipefail

BUCKET="${1:?Usage: ./package.sh <lambda-code-bucket>}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$SCRIPT_DIR/_build"

echo "==> Packaging simulation Lambda functions"
echo "    Source: $SCRIPT_DIR"
echo "    Bucket: s3://$BUCKET/simulation/"
echo ""

mkdir -p "$BUILD_DIR"

FUNCTIONS=(
  "seeder"
  "log_generator"
  "metric_generator"
  "anomaly_injector"
)

for FN in "${FUNCTIONS[@]}"; do
  echo "  Packaging: $FN"

  PYSCRIPT="$BUILD_DIR/pack.py"
  cat > "$PYSCRIPT" << PYEOF
import zipfile, sys
src = sys.argv[1]
dst = sys.argv[2]
name = sys.argv[3]
with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(src, name)
PYEOF

  python "$PYSCRIPT" \
    "$SCRIPT_DIR/${FN}.py" \
    "$BUILD_DIR/${FN}.zip" \
    "${FN}.py"

  aws s3 cp "$BUILD_DIR/${FN}.zip" "s3://$BUCKET/simulation/${FN}.zip" --quiet
  echo "    Uploaded: s3://$BUCKET/simulation/${FN}.zip"
done

rm -rf "$BUILD_DIR"
echo ""
echo "==> Simulation Lambda packaging complete (${#FUNCTIONS[@]} functions)"
