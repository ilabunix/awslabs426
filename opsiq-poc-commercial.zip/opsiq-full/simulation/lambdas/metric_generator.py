"""
OpsIQ Simulation — metric_generator.py
EventBridge schedule (every 5 min). Publishes synthetic CloudWatch metrics
under OpsIQ/Simulated namespace for all 3 simulated accounts.
Reads mode flag from DynamoDB to spike metrics during anomaly scenarios.
"""
import os
import random
import time

import boto3
from botocore.exceptions import ClientError

MODE_TABLE = os.environ['MODE_TABLE']
PROJECT    = os.environ['PROJECT_NAME']

cw    = boto3.client('cloudwatch')
ddb   = boto3.resource('dynamodb')
m_tbl = ddb.Table(MODE_TABLE)

NAMESPACE = 'OpsIQ/Simulated'

# (metric_name, unit, normal_range, anomaly_range)
METRIC_PROFILES = {
    'sim-app-a': [
        ('ALB_5xx_Rate',          'Percent', (0.1, 0.5),   (15.0, 35.0)),
        ('ECS_CPUUtilization',    'Percent', (20.0, 45.0), (88.0, 99.0)),
        ('ECS_MemoryUtilization', 'Percent', (40.0, 60.0), (95.0, 99.9)),
        ('RDS_Connections',       'Count',   (10.0, 30.0), (95.0, 100.0)),
        ('Lambda_Errors',         'Count',   (0.0, 2.0),   (12.0, 25.0)),
        ('ALB_RequestCount',      'Count',   (100.0, 500.0),(80.0, 150.0)),
    ],
    'sim-app-b': [
        ('Lambda_Duration',       'Milliseconds', (80.0, 300.0), (13000.0, 15000.0)),
        ('Lambda_Errors',         'Count',        (0.0, 1.0),    (8.0, 20.0)),
        ('Lambda_Throttles',      'Count',        (0.0, 0.0),    (5.0, 15.0)),
        ('DynamoDB_ThrottledRequests', 'Count',   (0.0, 0.0),    (10.0, 30.0)),
    ],
    'sim-app-c': [
        ('ALB_5xx_Rate',          'Percent', (0.0, 0.3),   (5.0, 12.0)),
        ('ECS_CPUUtilization',    'Percent', (15.0, 35.0), (70.0, 85.0)),
        ('ECS_MemoryUtilization', 'Percent', (30.0, 50.0), (75.0, 90.0)),
        ('Redis_ConnectionCount', 'Count',   (5.0, 20.0),  (0.0, 1.0)),
    ],
}


def _get_mode(account_id: str) -> str:
    try:
        resp = m_tbl.get_item(Key={'accountId': account_id})
        return resp.get('Item', {}).get('mode', 'normal')
    except ClientError:
        return 'normal'


def handler(event, _context):
    total_metrics = 0
    metric_data   = []

    for account_id, profiles in METRIC_PROFILES.items():
        mode = _get_mode(account_id)

        for metric_name, unit, normal_range, anomaly_range in profiles:
            value_range = anomaly_range if mode == 'anomaly' else normal_range
            value       = random.uniform(*value_range)

            metric_data.append({
                'MetricName': metric_name,
                'Dimensions': [
                    {'Name': 'AccountId',   'Value': account_id},
                    {'Name': 'Environment', 'Value': 'poc'},
                ],
                'Value':     round(value, 2),
                'Unit':      unit,
                'Timestamp': time.time(),
            })
            total_metrics += 1

    # CloudWatch accepts max 20 metrics per put_metric_data call
    for i in range(0, len(metric_data), 20):
        cw.put_metric_data(
            Namespace=NAMESPACE,
            MetricData=metric_data[i:i + 20],
        )

    print(f'Metric generator | published={total_metrics} metrics')
    return {'totalMetrics': total_metrics}
