"""
OpsIQ Simulation — log_generator.py
EventBridge schedule (every 2 min). Generates realistic log events for
sim-app-a, sim-app-b, and sim-app-c and writes them to the central Kinesis stream.
Reads a DynamoDB mode flag set by anomaly_injector to switch to error-mode output.
"""
import json
import os
import random
import time
import uuid

import boto3
from botocore.exceptions import ClientError

LOG_STREAM_NAME = os.environ['LOG_STREAM_NAME']
MODE_TABLE      = os.environ['MODE_TABLE']
PROJECT         = os.environ['PROJECT_NAME']

kinesis = boto3.client('kinesis')
ddb     = boto3.resource('dynamodb')
m_tbl   = ddb.Table(MODE_TABLE)

# ─── NORMAL LOG TEMPLATES ──────────────────────────────────────────────────
NORMAL_LOGS = {
    'sim-app-a': [
        ('INFO',  '/aws/ecs/sim-app-a-api',       'Request completed: POST /api/v1/payments status=200 duration={}ms'),
        ('INFO',  '/aws/ecs/sim-app-a-api',       'Database connection acquired from pool. Pool size: {}/50'),
        ('INFO',  '/aws/ecs/sim-app-a-api',       'Health check passed. ECS task healthy.'),
        ('WARN',  '/aws/ecs/sim-app-a-api',       'Slow query detected: SELECT * FROM transactions WHERE user_id={} duration={}ms'),
        ('INFO',  '/aws/lambda/payment-processor', 'Payment processed successfully. transaction_id={} amount=${}'),
        ('INFO',  '/aws/lambda/payment-processor', 'Lambda warm start. Execution time: {}ms memory_used={}MB'),
        ('WARN',  '/aws/rds/sim-app-a-postgres',  'Connection count approaching limit: {}/100'),
    ],
    'sim-app-b': [
        ('INFO',  '/aws/lambda/sim-app-b-handler', 'API request handled: GET /users/{} status=200 duration={}ms'),
        ('INFO',  '/aws/lambda/sim-app-b-handler', 'DynamoDB GetItem successful. table=sim-app-b-data key={} consumed_RCU=0.5'),
        ('INFO',  '/aws/lambda/sim-app-b-handler', 'Lambda cold start initialised. Runtime: nodejs18.x'),
        ('WARN',  '/aws/lambda/sim-app-b-handler', 'DynamoDB throttling detected. Retrying with backoff. attempt={}'),
    ],
    'sim-app-c': [
        ('INFO',  '/aws/ecs/sim-app-c-web',        'HTTP request served: GET /dashboard status=200 cache=HIT duration={}ms'),
        ('INFO',  '/aws/ecs/sim-app-c-web',        'Redis cache hit rate: {}%. Connected to {} nodes'),
        ('INFO',  '/aws/ecs/sim-app-c-web',        'ECS health check succeeded. Task: {} status=RUNNING'),
        ('WARN',  '/aws/ecs/sim-app-c-web',        'Redis connection latency elevated: {}ms (threshold: 50ms)'),
    ],
}

# ─── ANOMALY LOG TEMPLATES (OOM scenario for sim-app-a) ────────────────────
ANOMALY_LOGS = {
    'sim-app-a': [
        ('ERROR', '/aws/ecs/sim-app-a-api',        'java.lang.OutOfMemoryError: Java heap space\n\tat com.simapp.PaymentService.processPayment(PaymentService.java:142)'),
        ('ERROR', '/aws/ecs/sim-app-a-api',        'FATAL: ECS task ran out of memory. Container memory limit exceeded. Limit: 2048MB Used: 2049MB'),
        ('ERROR', '/aws/lambda/payment-processor', 'Runtime.ExitError: RequestId: {} Process exited before completing request'),
        ('WARN',  '/aws/ecs/sim-app-a-api',        'GC overhead limit exceeded. Application may be experiencing memory pressure.'),
        ('ERROR', '/aws/rds/sim-app-a-postgres',   'FATAL: remaining connection slots reserved for replication superuser connections'),
    ],
    'sim-app-b': [
        ('ERROR', '/aws/lambda/sim-app-b-handler', 'Task timed out after 15.00 seconds'),
        ('ERROR', '/aws/lambda/sim-app-b-handler', 'ProvisionedThroughputExceededException: The level of configured provisioned throughput for the table was exceeded'),
    ],
    'sim-app-c': [
        ('ERROR', '/aws/ecs/sim-app-c-web',        'ECONNREFUSED: Redis connection refused at 127.0.0.1:6379'),
        ('ERROR', '/aws/ecs/sim-app-c-web',        'Health check failed 3 consecutive times. Task will be replaced.'),
    ],
}


def _get_mode(account_id: str) -> str:
    """Read mode flag from DynamoDB — 'normal' or 'anomaly'."""
    try:
        resp = m_tbl.get_item(Key={'accountId': account_id})
        return resp.get('Item', {}).get('mode', 'normal')
    except ClientError:
        return 'normal'


def _generate_log_events(account_id: str, mode: str) -> list:
    """Generate a batch of 5-10 realistic log events for an account."""
    templates = ANOMALY_LOGS.get(account_id, []) if mode == 'anomaly' \
                else NORMAL_LOGS.get(account_id, [])
    if not templates:
        return []

    events = []
    count  = random.randint(5, 10) if mode == 'normal' else random.randint(8, 15)

    for _ in range(count):
        level, log_group, template = random.choice(templates)
        # Fill in {} placeholders with plausible values
        message = template.format(
            random.randint(10, 2000),   # duration or id
            random.randint(1, 999),     # secondary value
            str(uuid.uuid4())[:8],      # short ID
            random.randint(50, 250),    # memory
        ) if '{}' in template else template

        events.append({
            'logGroup':  log_group,
            'timestamp': int(time.time() * 1000),
            'level':     level,
            'message':   message,
        })
    return events


def handler(event, _context):
    accounts     = ['sim-app-a', 'sim-app-b', 'sim-app-c']
    total_events = 0

    for account_id in accounts:
        mode   = _get_mode(account_id)
        events = _generate_log_events(account_id, mode)

        if not events:
            continue

        # Group events by log group and write each group as one Kinesis record
        by_group: dict = {}
        for e in events:
            by_group.setdefault(e['logGroup'], []).append(e)

        for log_group, group_events in by_group.items():
            payload = {
                'accountId':  account_id,
                'logGroup':   log_group,
                'logEvents':  group_events,
                'eventCount': len(group_events),
                'source':     'opsiq.simulation.logs',
            }
            kinesis.put_record(
                StreamName=LOG_STREAM_NAME,
                Data=json.dumps(payload).encode('utf-8'),
                PartitionKey=account_id,
            )
            total_events += len(group_events)

    print(f'Log generator | total_events={total_events} | accounts={len(accounts)}')
    return {'totalEvents': total_events}
