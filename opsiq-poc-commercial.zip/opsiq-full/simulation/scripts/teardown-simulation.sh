#!/usr/bin/env bash
# opsiq-poc/simulation/scripts/teardown-simulation.sh
# Removes simulation stacks cleanly without touching central.
# Run this when POC passes go/no-go review.
set -euo pipefail

PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Simulation — Teardown (POC ONLY)         ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Central stacks will NOT be affected.            ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
read -r -p "Type 'delete-simulation' to confirm: " CONFIRM
if [[ "$CONFIRM" != "delete-simulation" ]]; then
  echo "Aborted."
  exit 0
fi

STACKS=(
  "${PROJECT}-sim-generators"
  "${PROJECT}-sim-data"
)

echo ""
for STACK in "${STACKS[@]}"; do
  if aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" &>/dev/null; then
    echo "Deleting: $STACK"
    aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
    aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
    echo "  ✓ Deleted: $STACK"
  else
    echo "Skipping (not found): $STACK"
  fi
done

# Clean simulated account data from DynamoDB
echo ""
echo "Removing simulated account entries from DynamoDB..."
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

for SIM_ACCOUNT in sim-app-a sim-app-b sim-app-c; do
  aws dynamodb delete-item \
    --table-name "${PROJECT}-HealthScores" \
    --key "{\"accountId\": {\"S\": \"${SIM_ACCOUNT}\"}}" \
    --region "$REGION" 2>/dev/null && echo "  Removed HealthScores: $SIM_ACCOUNT" || true

  aws s3 rm "s3://${PROJECT}-topology-${ACCOUNT_ID}/${SIM_ACCOUNT}/" \
    --recursive --quiet 2>/dev/null && echo "  Removed topology: $SIM_ACCOUNT" || true
done

echo ""
echo "✓ Simulation teardown complete. Central stack is unaffected."
echo "  Next: deploy product-account-agent into real product accounts."
