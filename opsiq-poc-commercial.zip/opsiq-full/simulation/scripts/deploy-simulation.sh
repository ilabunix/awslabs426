#!/usr/bin/env bash
# opsiq-poc/simulation/scripts/deploy-simulation.sh
# Deploys the 2 simulation stacks. Central must be fully deployed first.
#
# Usage:
#   export AWS_PROFILE=your-govcloud-profile
#   export LAMBDA_CODE_BUCKET=opsiq-lambda-pkgs-<account-id>
#   ./deploy-simulation.sh
set -euo pipefail

trap 'echo ""; echo "ERROR: deploy-simulation.sh failed at line $LINENO. Check the output above."; exit 1' ERR

PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"
LAMBDA_CODE_BUCKET="${LAMBDA_CODE_BUCKET:?Set LAMBDA_CODE_BUCKET env var}"
CFN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../cloudformation" && pwd)"
LAMBDA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../lambdas" && pwd)"

DEPLOY_FLAGS="--region $REGION --no-fail-on-empty-changeset"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Simulation — Deploy (POC ONLY)           ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Verify central stacks are present
echo "Verifying central stacks are deployed..."
aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query 'Stacks[0].StackStatus' --output text | grep -q "COMPLETE" \
  || { echo "ERROR: Central stacks not found. Run deploy-central.sh first."; exit 1; }
echo "  ✓ Central stacks confirmed"
echo ""

# Package simulation Lambdas
echo "Step 0/2 — Package simulation Lambda functions"
bash "$LAMBDA_DIR/package.sh" "$LAMBDA_CODE_BUCKET"
echo ""

# Stack 1 — Seed data
echo "Step 1/2 — Seed synthetic topology data"
aws cloudformation deploy \
  --template-file "$CFN_DIR/01-sim-data.yaml" \
  --stack-name "${PROJECT}-sim-data" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Sim data seeded (topology built for sim-app-a, sim-app-b, sim-app-c)"
echo ""

# Stack 2 — Generators
echo "Step 2/2 — Deploy log/metric generators and anomaly injector"
aws cloudformation deploy \
  --template-file "$CFN_DIR/02-sim-generators.yaml" \
  --stack-name "${PROJECT}-sim-generators" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Simulation generators deployed and running"
echo ""

# Print injector name for convenience
INJECTOR_NAME=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-sim-generators" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='AnomalyInjectorName'].OutputValue" \
  --output text)

echo "╔══════════════════════════════════════════════════╗"
echo "║  Simulation Deployed                             ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Generators running every 2/5 minutes            ║"
echo "║  Anomaly injector: $INJECTOR_NAME"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Run demo scenario (wait 3-5 min after for incident to appear on dashboard):"
echo ""
echo "  aws lambda invoke \\"
echo "    --function-name $INJECTOR_NAME \\"
echo "    --payload '{\"scenario\": \"ecs-oom\", \"accountId\": \"sim-app-a\"}' \\"
echo "    --region $REGION response.json && cat response.json"
echo ""
echo "Available scenarios: ecs-oom | api-latency | rds-exhaustion | novel-pattern"
