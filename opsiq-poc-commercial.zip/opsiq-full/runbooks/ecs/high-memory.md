# ECS Task High Memory / OutOfMemoryError

**Severity:** HIGH  
**Affected Services:** ECS Fargate, ALB, downstream RDS/Lambda  
**Typical Detection Time:** 2–5 minutes after first OOM log  

---

## What This Looks Like

- ECS task `MemoryUtilization` > 90% sustained for 3+ minutes
- `java.lang.OutOfMemoryError: Java heap space` in container logs
- ALB 5xx rate rising as OOM tasks restart and drop in-flight requests
- Task restart loop: ECS replaces the task, it re-fills memory, restarts again
- RDS connection pool not releasing because tasks are killed mid-transaction

---

## Immediate Actions (First 5 Minutes)

### 1. Confirm the affected task and service
```bash
CLUSTER=<cluster-name>
SERVICE=<service-name>

aws ecs describe-services \
  --cluster $CLUSTER \
  --services $SERVICE \
  --query 'services[0].{desired:desiredCount,running:runningCount,pending:pendingCount}'
```

Expected in incident: `running < desired`, `pending > 0`

### 2. Check memory metrics for the last 30 minutes
```bash
aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name MemoryUtilization \
  --dimensions Name=ClusterName,Value=$CLUSTER Name=ServiceName,Value=$SERVICE \
  --start-time $(date -u -d '30 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Maximum \
  --query 'sort_by(Datapoints, &Timestamp)[-5:]'
```

### 3. Get the last OOM log entries
```bash
LOG_GROUP=/aws/ecs/<service-name>

aws logs filter-log-events \
  --log-group-name $LOG_GROUP \
  --start-time $(date -u -d '30 minutes ago' +%s000) \
  --filter-pattern "OutOfMemory OR heap space OR OOM" \
  --query 'events[-10:].[timestamp,message]' \
  --output table
```

---

## Root Cause Investigation

### Check if this is a memory leak (gradual) or spike (sudden)

**Gradual (leak):** MemoryUtilization trend shows steady climb over hours/days  
→ Code-level memory leak, likely unclosed connections or unbounded cache growth

**Sudden spike:** MemoryUtilization was normal, then jumped  
→ Large payload processing, batch job, or traffic spike causing heap exhaustion

### Check JVM heap settings (Java services)
```bash
# Find the task definition to see memory/CPU limits and JVM flags
aws ecs describe-task-definition \
  --task-definition <task-def-name> \
  --query 'taskDefinition.containerDefinitions[0].{memory:memory,cpu:cpu,environment:environment}'
```

Look for `JAVA_OPTS` or `JVM_OPTS` environment variable.  
If `-Xmx` is not set or is set too low relative to the container memory limit, tasks will OOM.

**Rule of thumb:** `-Xmx` should be 75% of the container memory limit.  
Example: 2048 MB container → `-Xmx1536m`

---

## Containment

### Option A — Increase task memory limit (fastest path)
```bash
# Get current task definition
TASK_DEF=$(aws ecs describe-services \
  --cluster $CLUSTER --services $SERVICE \
  --query 'services[0].taskDefinition' --output text)

# Register new task definition with higher memory
# Edit memory value and register:
aws ecs register-task-definition \
  --cli-input-json file://task-def-updated.json

# Update service to use new task definition
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --task-definition <new-task-def-arn>
```

### Option B — Reduce task count to stabilize (if memory increase not possible immediately)
```bash
# Scale down to 1 task to reduce memory pressure while investigating
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --desired-count 1
```

### Option C — Force new deployment (clears memory state, buys time)
```bash
aws ecs update-service \
  --cluster $CLUSTER \
  --service $SERVICE \
  --force-new-deployment
```

---

## RDS Connection Leak (common co-symptom)

When ECS tasks OOM and restart mid-transaction, database connections may not be released.

```bash
# Check current connection count
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name DatabaseConnections \
  --dimensions Name=DBClusterIdentifier,Value=<cluster-id> \
  --start-time $(date -u -d '30 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 --statistics Maximum
```

If connections are elevated, a forced ECS deployment (Option C above) will close stale connections as old tasks terminate cleanly.

---

## Prevention

| Action | Impact | Effort |
|--------|--------|--------|
| Set explicit `-Xmx` in JVM flags | Prevents heap growth beyond safe limit | Low |
| Add CloudWatch alarm on MemoryUtilization > 80% | Early warning before OOM | Low |
| Enable ECS container insights | Better visibility into memory trends | Low |
| Add connection pool max size in application config | Prevents connection exhaustion on restart | Medium |
| Implement heap dump on OOM in task definition | Easier post-mortem analysis | Medium |

---

## Escalation

If tasks continue restarting after memory limit increase:
1. Pull a heap dump from a running task before it OOMs (if possible)
2. Engage the application team with: task definition ARN, log group name, time range of incident
3. Check recent deployments — new code may have introduced a memory leak

**P1 threshold:** Service running count drops to 0 (complete outage)
