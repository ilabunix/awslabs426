# ALB 5xx Error Rate Spike

**Severity:** HIGH  
**Affected Services:** ALB, ECS targets, upstream clients  
**Typical Detection Time:** 2–3 minutes after spike begins  

---

## What This Looks Like

- ALB `HTTPCode_ELB_5XX_Count` or `HTTPCode_Target_5XX_Count` elevated
- Error rate > 5% of total requests
- May accompany ECS task restarts, OOM, or downstream DB issues
- Client-facing impact: API requests returning 500/502/503/504

---

## Distinguish ELB 5xx vs Target 5xx

This is the critical first diagnostic step.

| Metric | Source | Meaning |
|--------|--------|---------|
| `HTTPCode_ELB_5XX_Count` | ALB itself | ALB cannot reach targets — targets unhealthy or capacity issue |
| `HTTPCode_Target_5XX_Count` | Targets (ECS tasks) | Targets are returning 500s — application error |

```bash
ALB_ARN_SUFFIX=<app/name/id-from-arn>

# Check both metrics over last 15 min
for METRIC in HTTPCode_ELB_5XX_Count HTTPCode_Target_5XX_Count RequestCount; do
  echo "--- $METRIC ---"
  aws cloudwatch get-metric-statistics \
    --namespace AWS/ApplicationELB \
    --metric-name $METRIC \
    --dimensions Name=LoadBalancer,Value=$ALB_ARN_SUFFIX \
    --start-time $(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
    --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
    --period 60 --statistics Sum \
    --query 'sort_by(Datapoints, &Timestamp)[-5:].[Timestamp,Sum]' \
    --output table
done
```

---

## If ELB 5xx (502/503 — ALB can't reach targets)

### Check target group health
```bash
TARGET_GROUP_ARN=<arn>

aws elbv2 describe-target-health \
  --target-group-arn $TARGET_GROUP_ARN \
  --query 'TargetHealthDescriptions[*].{Target:Target.Id,State:TargetHealth.State,Reason:TargetHealth.Reason}'
```

**Unhealthy targets → ECS task issue.** Follow the ECS high-memory or high-CPU runbook.

### Check ECS service task count
```bash
aws ecs describe-services \
  --cluster <cluster> --services <service> \
  --query 'services[0].{desired:desiredCount,running:runningCount,pending:pendingCount}'
```

If `running = 0`: complete outage — force new deployment immediately.

---

## If Target 5xx (application returning 500s)

### Get recent error logs from ECS tasks
```bash
aws logs filter-log-events \
  --log-group-name /aws/ecs/<service-name> \
  --start-time $(date -u -d '15 minutes ago' +%s000) \
  --filter-pattern "?ERROR ?500 ?exception ?Exception ?FATAL" \
  --limit 20 \
  --query 'events[*].[timestamp,message]' --output table
```

### Common 500 patterns and actions

| Log Pattern | Likely Cause | Action |
|-------------|--------------|--------|
| `Connection refused` to DB | RDS down or connections exhausted | See RDS runbook |
| `Timeout` calling downstream API | Dependency slow | Check dependent service |
| `NullPointerException` / `AttributeError` | Bug in recent deployment | Roll back |
| `OutOfMemoryError` | Memory exhausted | See ECS memory runbook |
| No obvious error, just 500 | Application logic error | Check application logs more deeply |

---

## Containment

### If caused by bad deployment — roll back
```bash
# Get previous task definition revision
aws ecs describe-task-definition \
  --task-definition <task-def-family> \
  --query 'taskDefinition.revision'

# Roll back to previous revision (e.g. revision 14)
aws ecs update-service \
  --cluster <cluster> \
  --service <service> \
  --task-definition <task-def-family>:14
```

### If no recent deployment — force new deployment (clears bad state)
```bash
aws ecs update-service \
  --cluster <cluster> \
  --service <service> \
  --force-new-deployment
```

---

## Prevention

| Action | Impact | Effort |
|--------|--------|--------|
| CloudWatch alarm: 5xx rate > 2% for 5 min | Catch before user impact | Low |
| ALB access logs to S3 | Post-mortem analysis | Low |
| Health check path returns 200 only when DB is reachable | Faster unhealthy detection | Medium |
| Blue/green deployments via CodeDeploy | Safe rollback in 60 seconds | High |
