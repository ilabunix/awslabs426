# OpsIQ POC

AI-powered Operational Intelligence Platform — AWS Commercial POC.

## What This Is

OpsIQ is an ops engineering copilot that ingests signals from simulated product accounts,
detects anomalies using a Bloom filter pipeline, correlates them into incidents,
and generates AI-powered summaries using Amazon Bedrock (Claude Sonnet) — all visible
on a real-time React dashboard.

## Repository Structure

```
opsiq-poc/
├── central/                  ← Ops account — deployed forever
│   ├── cloudformation/       ← 6 CFN stacks (deploy in order 01 → 06)
│   ├── lambdas/              ← 9 Python Lambda functions + package.sh
│   └── scripts/              ← deploy-central.sh / teardown-central.sh
│
├── simulation/               ← POC only — delete after POC passes
│   ├── cloudformation/       ← 2 CFN stacks
│   ├── lambdas/              ← 4 Python Lambda functions + package.sh
│   └── scripts/              ← deploy-simulation.sh / teardown-simulation.sh
│
├── runbooks/                 ← 5 operational runbooks (uploaded to S3)
│   ├── ecs/
│   ├── alb/
│   ├── rds/
│   └── cloudtrail/
│
└── scripts/
    ├── bootstrap.sh          ← Run once first
    └── deploy-all.sh         ← Deploys everything
```

## Prerequisites

- AWS CLI configured for AWS Commercial (`us-west-2`)
- Bedrock model access enabled: `anthropic.claude-sonnet-4-6-20251001-v1:0`
- `zip` installed locally (`apt install zip` / `brew install zip`)

Enable Bedrock in AWS Commercial console:
1. Amazon Bedrock → Model Access → Request model access
2. Select Claude Sonnet → Submit

## Quick Start

```bash
# 1. Configure AWS credentials
export AWS_PROFILE=your-govcloud-profile
export REGION=us-west-2

# 2. Bootstrap (one time — creates Lambda code bucket)
./scripts/bootstrap.sh

# 3. Deploy everything
export LAMBDA_CODE_BUCKET=opsiq-lambda-pkgs-<account-id>
./scripts/deploy-all.sh
```

Full deployment takes 10–15 minutes. The script prints the dashboard URL at the end.

## Demo — Trigger a Live Incident

After deployment, fire a phased anomaly scenario:

```bash
aws lambda invoke \
  --function-name opsiq-sim-anomaly-injector \
  --payload '{"scenario": "ecs-oom", "accountId": "sim-app-a"}' \
  --region us-west-2 \
  response.json && cat response.json
```

**Available scenarios:**

| Scenario | Account | What It Simulates |
|---|---|---|
| `ecs-oom` | sim-app-a | ECS OOM → ALB 5xx → novel log pattern |
| `api-latency` | sim-app-b | Lambda timeout → elevated error count |
| `rds-exhaustion` | sim-app-a | RDS connection limit → ECS CPU spike |
| `novel-pattern` | sim-app-c | Redis ECONNREFUSED → ALB 5xx |

Watch the dashboard — within 3–5 minutes you will see:
1. Health score drop on the affected account card
2. Anomaly cards appear in the feed
3. Incident card created with correlated signals
4. AI summary generated (Bedrock) with headline, investigation steps, runbook reference

## Architecture

### Data Flow

```
Simulation Generators (every 2–5 min)
    │
    ├─ log-generator   → Kinesis log-stream → log-processor → BloomFilter DynamoDB
    ├─ metric-generator → CloudWatch OpsIQ/Simulated namespace
    └─ anomaly-injector → SQS anomaly-events → correlator
                              │
                              ├─ 2+ signals in 15-min window → incident cluster
                              │       │
                              │       └─ incident-assembler → Bedrock → AI summary
                              │
                              └─ health-scorer (every 5 min)
                                      │
                                      └─ ws-broadcaster → WebSocket → Dashboard
```

### Central Stack (8 CloudFormation resources)

| Stack | Resources |
|---|---|
| 01-storage | S3 ×5, DynamoDB ×7 |
| 02-ingestion | Kinesis ×1, SQS ×3, EventBridge ×1 |
| 03-iam | IAM roles ×2 |
| 04-lambdas-central | Lambda ×9, ESM ×2 |
| 05-api | REST API Gateway + WebSocket API |
| 06-dashboard | S3 website config, schedule activation, runbook index |

### Monthly Cost (POC)

| Mode | Estimated Cost |
|---|---|
| Idle (generators only) | $30–45/month |
| Active demo days | ~$70–90/month |
| Budget ceiling | $200/month |

## After POC Passes

1. Run `simulation/scripts/teardown-simulation.sh`
2. Deploy `product-account-agent/` into each real product account
3. Central stack requires no changes

## Troubleshooting

### Bedrock returns AccessDeniedException
```bash
aws bedrock list-foundation-models --region us-west-2
```
Model not listed → request access in Bedrock console.

### State parser not building topology
Check seeder Lambda logs:
```bash
aws logs tail /aws/lambda/opsiq-sim-seeder --follow --region us-west-2
```

### Dashboard shows no accounts
Wait 10 minutes after simulation deploy. HealthScores table is seeded by the seeder Lambda.
Verify:
```bash
aws dynamodb scan --table-name opsiq-HealthScores --region us-west-2
```

### Incident assembler not generating AI summary
Check logs:
```bash
aws logs tail /aws/lambda/opsiq-incident-assembler --follow --region us-west-2
```
Common issue: Bedrock endpoint not reachable in AWS Commercial. Ensure model access is enabled.

### WebSocket not receiving updates
Check ws-broadcaster logs. WS_ENDPOINT env var must be set — this is done by the
`06-dashboard.yaml` custom resource. If it's empty, re-deploy stack 6.

## Dashboard

The React SPA lives in `dashboard/`. It connects to the REST API and WebSocket endpoints output by the central CloudFormation stacks.

### Stack
- React 18 + Vite
- Zustand (global state)
- D3 v7 (topology force graph)
- AWS Console visual design system

### Build and deploy

The `dashboard/build.sh` script does everything — it reads the API endpoints directly from CloudFormation outputs, runs `vite build`, and syncs the `dist/` folder to the S3 website bucket.

```bash
export AWS_PROFILE=your-govcloud-profile
export REGION=us-west-2
export PROJECT=opsiq

cd dashboard && ./build.sh
```

Run this after `deploy-central.sh` completes. The script will exit with an error if the central stacks are not yet deployed.

### Local development

```bash
cd dashboard
export VITE_API_URL=https://<rest-api-id>.execute-api.us-west-2.amazonaws.com/poc
export VITE_WS_URL=wss://<ws-api-id>.execute-api.us-west-2.amazonaws.com/poc
npm install
npm run dev
```

### Components

| File | Purpose |
|---|---|
| `src/store.js` | Zustand store — all data fetching, WebSocket merge, auto-refresh |
| `src/api.js` | REST + WebSocket client |
| `src/components/TopNav.jsx` | AWS-style navy top bar with region pill and live clock |
| `src/components/Sidebar.jsx` | Left navigation with incident badge counter |
| `src/components/Dashboard.jsx` | Main layout — orchestrates all panels |
| `src/components/MetricTiles.jsx` | 4 KPI tiles with sparklines |
| `src/components/AccountTable.jsx` | Account health table with animated score bars |
| `src/components/SignalFeed.jsx` | Sparkline metrics + anomaly event stream |
| `src/components/TopologyGraph.jsx` | D3 force-directed topology graph (zoom + pan) |
| `src/components/AIPanel.jsx` | Bedrock AI incident summary panel |
| `src/components/SignalFeed.jsx` | Also exports IncidentTable, DriftPanel, AlertBanner |
| `src/styles/aws.css` | Full AWS Console design system (variables, layout, components) |
