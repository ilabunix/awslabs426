"""
OpsIQ Central — health_scorer.py
EventBridge schedule (every 5 min). Scans all known accounts from HealthScores
table, recalculates score from recent anomalies, writes back with 6-min TTL.
"""
import json
import os
import time

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

ANOMALY_TABLE    = os.environ['ANOMALY_TABLE']
HEALTH_TABLE     = os.environ['HEALTH_TABLE']
BROADCASTER_NAME = os.environ['WS_BROADCASTER_NAME']
PROJECT          = os.environ['PROJECT_NAME']

ddb    = boto3.resource('dynamodb')
lmb    = boto3.client('lambda')
a_tbl  = ddb.Table(ANOMALY_TABLE)
h_tbl  = ddb.Table(HEALTH_TABLE)

SEVERITY_PENALTY = {'HIGH': 25, 'MEDIUM': 12, 'LOW': 5}
WINDOW_SECONDS   = 30 * 60   # 30-minute anomaly window
HEALTH_TTL       = 6 * 60    # 6-minute TTL on scores


def _get_known_accounts() -> list:
    """Scan HealthScores for currently tracked account IDs."""
    resp = h_tbl.scan(ProjectionExpression='accountId')
    return [item['accountId'] for item in resp.get('Items', [])]


def _calculate_score(account_id: str) -> int:
    cutoff = str(int((time.time() - WINDOW_SECONDS) * 1000))
    resp   = a_tbl.query(
        KeyConditionExpression=Key('accountId').eq(account_id) & Key('sortKey').gte(cutoff),
    )
    anomalies = resp.get('Items', [])
    score     = 100
    for a in anomalies:
        score -= SEVERITY_PENALTY.get(a.get('severity', 'LOW'), 5)
    return max(0, score)


def _write_score(account_id: str, score: int) -> None:
    h_tbl.put_item(Item={
        'accountId':   account_id,
        'score':       score,
        'calculatedAt': int(time.time()),
        'ttl':         int(time.time()) + HEALTH_TTL,
    })


def _broadcast_scores(scores: list) -> None:
    try:
        lmb.invoke(
            FunctionName=BROADCASTER_NAME,
            InvocationType='Event',
            Payload=json.dumps({
                'type': 'health_scores_bulk',
                'data': {'scores': scores},
            }),
        )
    except ClientError as e:
        print(f'Broadcast failed: {e}')


def handler(event, _context):
    accounts = _get_known_accounts()

    if not accounts:
        print('No accounts in HealthScores table yet — skipping')
        return

    updated = []
    for account_id in accounts:
        score = _calculate_score(account_id)
        _write_score(account_id, score)
        updated.append({'accountId': account_id, 'score': score})
        print(f'Health score | account={account_id} | score={score}')

    _broadcast_scores(updated)
    return {'updated': len(updated), 'scores': updated}
