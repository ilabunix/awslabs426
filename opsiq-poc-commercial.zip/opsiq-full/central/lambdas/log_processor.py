"""
OpsIQ Central — log_processor.py
Kinesis consumer. Extracts stable log signatures, checks DynamoDB Bloom filter,
emits HIGH severity anomaly to EventBridge when a novel pattern is detected.
"""
import base64
import hashlib
import json
import os
import re
import time

import boto3
from botocore.exceptions import ClientError

BLOOM_TABLE   = os.environ['BLOOM_TABLE']
ANOMALY_TABLE = os.environ['ANOMALY_TABLE']
SIGNAL_BUS    = os.environ['SIGNAL_BUS_NAME']
PROJECT       = os.environ['PROJECT_NAME']

ddb   = boto3.resource('dynamodb')
eb    = boto3.client('events')
bloom = ddb.Table(BLOOM_TABLE)
anom  = ddb.Table(ANOMALY_TABLE)

# Patterns stripped before hashing to produce a stable signature
_STRIP = [
    (re.compile(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?'), '<TS>'),
    (re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}', re.I), '<UUID>'),
    (re.compile(r'\b\d+\.\d+\.\d+\.\d+\b'), '<IP>'),
    (re.compile(r'\b[0-9a-fA-F]{32,}\b'), '<HASH>'),
    (re.compile(r'\b\d+\b'), '<N>'),
    (re.compile(r'\s+'), ' '),
]


def _signature(message: str) -> str:
    """Return a stable, normalised signature for a log line."""
    s = message.upper()
    for pattern, repl in _STRIP:
        s = pattern.sub(repl, s)
    return s.strip()


def _hash(account_id: str, sig: str) -> str:
    return hashlib.sha256(f'{account_id}:{sig}'.encode()).hexdigest()


def _is_novel(account_id: str, sig_hash: str) -> bool:
    """Return True if this signature hash has never been seen before."""
    try:
        resp = bloom.get_item(
            Key={'accountId': account_id, 'signatureHash': sig_hash},
            ProjectionExpression='signatureHash',
        )
        return 'Item' not in resp
    except ClientError:
        return False


def _record_seen(account_id: str, sig_hash: str) -> None:
    """Mark a signature as known in the Bloom filter table."""
    bloom.put_item(Item={
        'accountId':     account_id,
        'signatureHash': sig_hash,
        'seenAt':        int(time.time()),
        'ttl':           int(time.time()) + 30 * 86400,  # 30 days
    })


def _store_anomaly(account_id: str, anomaly_id: str, signature: str,
                    log_group: str, sample: str) -> None:
    ts = str(int(time.time() * 1000))
    anom.put_item(Item={
        'accountId':   account_id,
        'sortKey':     f'{ts}#{anomaly_id}',
        'anomalyId':   anomaly_id,
        'anomalyType': 'novel_log_pattern',
        'severity':    'HIGH',
        'signature':   signature,
        'logGroup':    log_group,
        'sample':      sample[:500],
        'timestamp':   ts,
        'ttl':         int(time.time()) + 30 * 86400,
    })


def _emit_anomaly_event(account_id: str, anomaly_id: str,
                         signature: str, log_group: str) -> None:
    eb.put_events(Entries=[{
        'Source':     'opsiq.logs',
        'DetailType': 'NovelLogPattern',
        'EventBusName': SIGNAL_BUS,
        'Detail': json.dumps({
            'accountId':   account_id,
            'anomalyId':   anomaly_id,
            'anomalyType': 'novel_log_pattern',
            'severity':    'HIGH',
            'signature':   signature,
            'logGroup':    log_group,
            'timestamp':   int(time.time() * 1000),
        }),
    }])


def handler(event, _context):
    records = event.get('Records', [])
    novel_count = 0

    for record in records:
        # Kinesis records are base64-encoded
        raw = base64.b64decode(record['kinesis']['data']).decode('utf-8')
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            continue

        account_id = payload.get('accountId', 'unknown')
        log_group  = payload.get('logGroup', 'unknown')
        log_events = payload.get('logEvents', [])

        for evt in log_events:
            message = evt.get('message', '')
            if not message:
                continue

            sig      = _signature(message)
            sig_hash = _hash(account_id, sig)

            if _is_novel(account_id, sig_hash):
                import uuid
                anomaly_id = str(uuid.uuid4())
                _record_seen(account_id, sig_hash)
                _store_anomaly(account_id, anomaly_id, sig, log_group, message)
                _emit_anomaly_event(account_id, anomaly_id, sig, log_group)
                novel_count += 1
                print(f'NOVEL pattern detected | account={account_id} | group={log_group}')
            else:
                _record_seen(account_id, sig_hash)  # refresh TTL

    print(f'Processed {len(records)} records | {novel_count} novel patterns')
    return {'batchItemFailures': []}
