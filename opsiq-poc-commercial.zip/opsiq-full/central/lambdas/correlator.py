"""
OpsIQ Central — correlator.py
SQS consumer (batch=10). Stores anomalies, queries last 15-min window,
groups correlated signals into incident clusters, triggers incident-assembler.
"""
import json
import os
import time
import uuid

import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

ANOMALY_TABLE   = os.environ['ANOMALY_TABLE']
INCIDENT_TABLE  = os.environ['INCIDENT_TABLE']
TOPOLOGY_TABLE  = os.environ['TOPOLOGY_TABLE']
HEALTH_TABLE    = os.environ['HEALTH_TABLE']
ASSEMBLER_NAME  = os.environ['INCIDENT_ASSEMBLER_NAME']
BROADCASTER_NAME = os.environ['WS_BROADCASTER_NAME']
WINDOW_MINUTES  = int(os.environ.get('CORRELATION_WINDOW_MINUTES', '15'))
PROJECT         = os.environ['PROJECT_NAME']

ddb    = boto3.resource('dynamodb')
lmb    = boto3.client('lambda')
a_tbl  = ddb.Table(ANOMALY_TABLE)
i_tbl  = ddb.Table(INCIDENT_TABLE)
t_tbl  = ddb.Table(TOPOLOGY_TABLE)
h_tbl  = ddb.Table(HEALTH_TABLE)

SEVERITY_RANK = {'HIGH': 3, 'MEDIUM': 2, 'LOW': 1}


def _store_anomaly(account_id: str, anomaly: dict) -> None:
    ts = str(int(time.time() * 1000))
    a_tbl.put_item(Item={
        'accountId':   account_id,
        'sortKey':     f'{ts}#{anomaly.get("anomalyId", str(uuid.uuid4()))}',
        'anomalyId':   anomaly.get('anomalyId', str(uuid.uuid4())),
        'anomalyType': anomaly.get('anomalyType', 'unknown'),
        'severity':    anomaly.get('severity', 'MEDIUM'),
        'details':     json.dumps(anomaly),
        'timestamp':   ts,
        'ttl':         int(time.time()) + 30 * 86400,
    })


def _query_recent_anomalies(account_id: str) -> list:
    cutoff = str(int((time.time() - WINDOW_MINUTES * 60) * 1000))
    resp = a_tbl.query(
        KeyConditionExpression=Key('accountId').eq(account_id) & Key('sortKey').gte(cutoff),
    )
    return resp.get('Items', [])


def _get_topology(account_id: str) -> list:
    """Return resource list for blast radius calculation."""
    resp = t_tbl.query(KeyConditionExpression=Key('accountId').eq(account_id))
    return resp.get('Items', [])


def _blast_radius(anomalies: list, topology: list) -> dict:
    """Identify directly and downstream-affected resources."""
    affected_types = set()
    for a in anomalies:
        details = json.loads(a.get('details', '{}'))
        atype = details.get('anomalyType', '')
        if 'ecs' in atype or 'memory' in atype or 'cpu' in atype:
            affected_types.update(['aws_ecs_service', 'aws_ecs_cluster'])
        if 'alb' in atype or '5xx' in atype:
            affected_types.update(['aws_alb', 'aws_lb'])
        if 'rds' in atype or 'database' in atype:
            affected_types.update(['aws_rds_instance', 'aws_rds_cluster'])
        if 'lambda' in atype:
            affected_types.add('aws_lambda_function')

    directly  = [r for r in topology if r.get('resourceType') in affected_types]
    downstream = [r for r in topology
                  if r.get('tier') in ('data', 'storage') and r not in directly]

    return {
        'directlyAffected':  [r.get('resourceName', r.get('resourceArn', '')) for r in directly],
        'potentiallyAffected': [r.get('resourceName', r.get('resourceArn', '')) for r in downstream[:5]],
        'resourceCount':     len(directly),
    }


def _determine_incident_type(anomalies: list) -> str:
    types = [json.loads(a.get('details', '{}')).get('anomalyType', '') for a in anomalies]
    if any('memory' in t or 'oom' in t for t in types): return 'ecs_high_memory'
    if any('cpu' in t for t in types):    return 'ecs_high_cpu'
    if any('5xx' in t or 'alb' in t for t in types): return 'alb_5xx'
    if any('rds' in t or 'database' in t for t in types): return 'rds_connection_exhaustion'
    if any('novel' in t for t in types):  return 'novel_log_pattern'
    return 'unknown'


def _create_incident(account_id: str, anomalies: list, blast: dict) -> dict:
    incident_id   = str(uuid.uuid4())
    max_severity  = max(anomalies, key=lambda a: SEVERITY_RANK.get(a.get('severity', 'LOW'), 0))
    incident_type = _determine_incident_type(anomalies)
    ts            = str(int(time.time() * 1000))

    item = {
        'incidentId':   incident_id,
        'accountId':    account_id,
        'timestamp':    ts,
        'status':       'OPEN',
        'severity':     max_severity.get('severity', 'MEDIUM'),
        'incidentType': incident_type,
        'signalCount':  len(anomalies),
        'signals':      [json.loads(a.get('details', '{}')) for a in anomalies],
        'blastRadius':  blast,
        'aiSummary':    None,  # Populated by incident-assembler
    }

    i_tbl.put_item(Item=item)
    return item


def _update_health_score(account_id: str, severity: str) -> int:
    """Recalculate and store health score based on recent anomalies."""
    cutoff = str(int((time.time() - 30 * 60) * 1000))
    resp = a_tbl.query(
        KeyConditionExpression=Key('accountId').eq(account_id) & Key('sortKey').gte(cutoff),
    )
    anomalies = resp.get('Items', [])

    score = 100
    for a in anomalies:
        sev = a.get('severity', 'LOW')
        score -= {'HIGH': 25, 'MEDIUM': 12, 'LOW': 5}.get(sev, 5)
    score = max(0, score)

    h_tbl.put_item(Item={
        'accountId': account_id,
        'score':     score,
        'updatedAt': int(time.time()),
        'ttl':       int(time.time()) + 6 * 60,  # 6-minute TTL
    })
    return score


def _invoke_assembler(incident: dict) -> None:
    lmb.invoke(
        FunctionName=ASSEMBLER_NAME,
        InvocationType='Event',  # Async
        Payload=json.dumps({'incident': incident}),
    )


def _broadcast(event_type: str, payload: dict) -> None:
    try:
        lmb.invoke(
            FunctionName=BROADCASTER_NAME,
            InvocationType='Event',
            Payload=json.dumps({'type': event_type, 'data': payload}),
        )
    except ClientError as e:
        print(f'Broadcast failed: {e}')


def handler(event, _context):
    for record in event.get('Records', []):
        try:
            body    = json.loads(record['body'])
            # EventBridge wraps in "detail", direct SQS messages are flat
            anomaly = body.get('detail', body)
            account_id = anomaly.get('accountId', 'unknown')

            _store_anomaly(account_id, anomaly)

            recent = _query_recent_anomalies(account_id)
            score  = _update_health_score(account_id, anomaly.get('severity', 'LOW'))

            # Broadcast health score update immediately
            _broadcast('health_score_updated', {'accountId': account_id, 'score': score})
            _broadcast('anomaly_detected', {**anomaly, 'accountId': account_id})

            # Correlate if 2+ anomalies in window
            if len(recent) >= 2:
                topology = _get_topology(account_id)
                blast    = _blast_radius(recent, topology)
                incident = _create_incident(account_id, recent, blast)

                _broadcast('incident_created', {
                    'incidentId': incident['incidentId'],
                    'accountId':  account_id,
                    'severity':   incident['severity'],
                    'signalCount': incident['signalCount'],
                    'status':     'OPEN',
                })

                # Only invoke Bedrock for HIGH severity incidents
                if incident['severity'] == 'HIGH':
                    _invoke_assembler(incident)

                print(f'Incident created | id={incident["incidentId"]} | '
                      f'account={account_id} | signals={len(recent)}')
            else:
                print(f'Anomaly stored | account={account_id} | '
                      f'window_count={len(recent)} | score={score}')

        except Exception as e:
            print(f'Correlator error: {e}')
            raise

    return {'batchItemFailures': []}
