"""
OpsIQ Central — drift_detector.py
EventBridge schedule (every 6 hours). Compares topology cache (expected from
tfstate) against a synthetic live resource list to detect infrastructure drift.
In POC the "live" state is generated synthetically with intentional discrepancies.
"""
import json
import os
import time
import uuid

import boto3
from boto3.dynamodb.conditions import Key

TOPOLOGY_TABLE = os.environ['TOPOLOGY_TABLE']
SIGNAL_BUS     = os.environ['SIGNAL_BUS_NAME']
PROJECT        = os.environ['PROJECT_NAME']

ddb   = boto3.resource('dynamodb')
eb    = boto3.client('events')
t_tbl = ddb.Table(TOPOLOGY_TABLE)

# Synthetic drift scenarios — simulates what real Describe* API calls would find
# Each scenario has resources that are "missing" and resources that are "extra"
DRIFT_SCENARIOS = {
    'sim-app-a': {
        'missing': [
            {'name': 'backup-lambda', 'type': 'aws_lambda_function',
             'reason': 'Function removed from tfstate but still running in account'},
        ],
        'extra': [
            {'name': 'temp-sg-debug', 'type': 'aws_security_group',
             'reason': 'Security group created manually during incident, not in tfstate'},
        ],
    },
    'sim-app-b': {
        'missing': [],
        'extra': [
            {'name': 'test-dynamodb-table', 'type': 'aws_dynamodb_table',
             'reason': 'Table created by developer for testing, never added to tfstate'},
        ],
    },
    'sim-app-c': {
        'missing': [
            {'name': 'redis-replica', 'type': 'aws_elasticache_cluster',
             'reason': 'Replica removed from config but CloudFormation did not delete it'},
        ],
        'extra': [],
    },
}


def _get_expected_resources(account_id: str) -> list:
    resp = t_tbl.query(KeyConditionExpression=Key('accountId').eq(account_id))
    return resp.get('Items', [])


def _detect_drift(account_id: str, expected: list) -> list:
    """
    In POC: compare expected topology against our synthetic drift scenario.
    In production: compare against Describe* API calls in the product account.
    """
    scenario  = DRIFT_SCENARIOS.get(account_id, {'missing': [], 'extra': []})
    drifts    = []
    now_ms    = int(time.time() * 1000)

    for m in scenario['missing']:
        drifts.append({
            'driftType':    'RESOURCE_MISSING',
            'resourceName': m['name'],
            'resourceType': m['type'],
            'reason':       m['reason'],
            'severity':     'MEDIUM',
            'detectedAt':   now_ms,
        })

    for e in scenario['extra']:
        drifts.append({
            'driftType':    'UNMANAGED_RESOURCE',
            'resourceName': e['name'],
            'resourceType': e['type'],
            'reason':       e['reason'],
            'severity':     'LOW',
            'detectedAt':   now_ms,
        })

    return drifts


def _emit_drift_events(account_id: str, drifts: list) -> None:
    if not drifts:
        return
    entries = []
    for drift in drifts:
        entries.append({
            'Source':       'opsiq.drift',
            'DetailType':   'InfrastructureDrift',
            'EventBusName': SIGNAL_BUS,
            'Detail': json.dumps({
                'accountId':  account_id,
                'anomalyId':  str(uuid.uuid4()),
                'anomalyType': 'infrastructure_drift',
                'severity':   drift['severity'],
                **drift,
            }),
        })
    # EventBridge allows max 10 entries per call
    for i in range(0, len(entries), 10):
        eb.put_events(Entries=entries[i:i + 10])


def handler(event, _context):
    # Get list of accounts from topology cache (use scan for simplicity in POC)
    all_accounts = set()
    resp = t_tbl.scan(ProjectionExpression='accountId')
    for item in resp.get('Items', []):
        all_accounts.add(item['accountId'])

    total_drift = 0
    for account_id in all_accounts:
        expected = _get_expected_resources(account_id)
        drifts   = _detect_drift(account_id, expected)
        _emit_drift_events(account_id, drifts)
        total_drift += len(drifts)
        print(f'Drift check | account={account_id} | '
              f'expected_resources={len(expected)} | drifts={len(drifts)}')

    return {'accountsChecked': len(all_accounts), 'totalDrifts': total_drift}
