"""
OpsIQ Central — ws_handler.py
Handles WebSocket $connect and $disconnect lifecycle events.
Stores active connection IDs in DynamoDB with 24-hour TTL.
"""
import os
import time

import boto3

WS_TABLE = os.environ['WS_TABLE']
PROJECT  = os.environ['PROJECT_NAME']

ddb   = boto3.resource('dynamodb')
table = ddb.Table(WS_TABLE)


def handler(event, _context):
    route        = event.get('requestContext', {}).get('routeKey', '$connect')
    connection_id = event.get('requestContext', {}).get('connectionId', '')

    if route == '$connect':
        table.put_item(Item={
            'connectionId': connection_id,
            'connectedAt':  int(time.time()),
            'ttl':          int(time.time()) + 24 * 3600,
        })
        print(f'WebSocket connected: {connection_id}')

    elif route == '$disconnect':
        table.delete_item(Key={'connectionId': connection_id})
        print(f'WebSocket disconnected: {connection_id}')

    return {'statusCode': 200}
