#!/usr/bin/env bash
# opsiq-poc/central/scripts/teardown-central.sh
# Removes all central OpsIQ CloudFormation stacks and S3 data.
# WARNING: This is irreversible. Run teardown-simulation.sh first.
set -euo pipefail

PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Central — TEARDOWN                       ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  This will permanently delete all OpsIQ stacks  ║"
echo "║  and ALL DATA including DynamoDB tables and S3.  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
read -r -p "Type 'delete-central' to confirm: " CONFIRM
if [[ "$CONFIRM" != "delete-central" ]]; then
  echo "Aborted."
  exit 0
fi

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Empty S3 buckets first (CloudFormation cannot delete non-empty buckets)
echo ""
echo "Emptying S3 buckets..."
for SUFFIX in topology runbooks tfstate signals dashboard; do
  BUCKET="${PROJECT}-${SUFFIX}-${ACCOUNT_ID}"
  if aws s3 ls "s3://$BUCKET" &>/dev/null; then
    aws s3 rm "s3://$BUCKET" --recursive --quiet
    echo "  Emptied: $BUCKET"
  fi
done

# Delete stacks in reverse order
STACKS=(
  "${PROJECT}-central-dashboard"
  "${PROJECT}-central-api"
  "${PROJECT}-central-lambdas"
  "${PROJECT}-central-iam"
  "${PROJECT}-central-ingestion"
  "${PROJECT}-central-storage"
)

echo ""
echo "Deleting CloudFormation stacks..."
for STACK in "${STACKS[@]}"; do
  if aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" &>/dev/null; then
    echo "  Deleting: $STACK"
    aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
    aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
    echo "  ✓ Deleted: $STACK"
  else
    echo "  Skipping (not found): $STACK"
  fi
done

echo ""
echo "✓ Central stack teardown complete."
