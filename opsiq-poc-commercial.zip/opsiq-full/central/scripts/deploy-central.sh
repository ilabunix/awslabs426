#!/usr/bin/env bash
# opsiq-poc/central/scripts/deploy-central.sh
# Deploys all 6 central OpsIQ CloudFormation stacks in order.
#
# Prerequisites:
#   - AWS CLI configured for GovCloud account
#   - Bedrock Claude Sonnet model enabled in the account
#   - LAMBDA_CODE_BUCKET must exist (created by bootstrap.sh)
#
# Usage:
#   export AWS_PROFILE=your-govcloud-profile
#   export LAMBDA_CODE_BUCKET=opsiq-lambda-pkgs-<account-id>
#   ./deploy-central.sh
set -euo pipefail

# Trap errors and show which line failed
trap 'echo ""; echo "ERROR: deploy-central.sh failed at line $LINENO. Check the output above."; exit 1' ERR

# ── CONFIGURATION ─────────────────────────────────────────────────────────
PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"
LAMBDA_CODE_BUCKET="${LAMBDA_CODE_BUCKET:?Set LAMBDA_CODE_BUCKET env var}"
CFN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../cloudformation" && pwd)"
LAMBDA_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../lambdas" && pwd)"

DEPLOY_FLAGS="--region $REGION --no-fail-on-empty-changeset"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Central — Deploy                         ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Project : $PROJECT"
echo "║  Region  : $REGION"
echo "║  Bucket  : $LAMBDA_CODE_BUCKET"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── PACKAGE LAMBDAS ────────────────────────────────────────────────────────
echo "Step 0/6 — Package and upload Lambda functions"
bash "$LAMBDA_DIR/package.sh" "$LAMBDA_CODE_BUCKET"
echo ""

# ── STACK 1 — STORAGE ─────────────────────────────────────────────────────
echo "Step 1/6 — Storage (S3 + DynamoDB)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/01-storage.yaml" \
  --stack-name "${PROJECT}-central-storage" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ Storage stack deployed"
echo ""

# ── STACK 2 — INGESTION ────────────────────────────────────────────────────
echo "Step 2/6 — Ingestion (Kinesis + SQS + EventBridge)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/02-ingestion.yaml" \
  --stack-name "${PROJECT}-central-ingestion" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ Ingestion stack deployed"
echo ""

# ── STACK 3 — IAM ─────────────────────────────────────────────────────────
echo "Step 3/6 — IAM Roles"
aws cloudformation deploy \
  --template-file "$CFN_DIR/03-iam.yaml" \
  --stack-name "${PROJECT}-central-iam" \
  --parameter-overrides ProjectName="$PROJECT" \
  --capabilities CAPABILITY_NAMED_IAM \
  $DEPLOY_FLAGS
echo "  ✓ IAM stack deployed"
echo ""

# ── STACK 4 — LAMBDAS ─────────────────────────────────────────────────────
echo "Step 4/6 — Lambda Functions"
aws cloudformation deploy \
  --template-file "$CFN_DIR/04-lambdas-central.yaml" \
  --stack-name "${PROJECT}-central-lambdas" \
  --parameter-overrides \
    ProjectName="$PROJECT" \
    LambdaCodeBucket="$LAMBDA_CODE_BUCKET" \
  --capabilities CAPABILITY_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Lambda stack deployed"
echo ""

# ── STACK 5 — API GATEWAY ─────────────────────────────────────────────────
echo "Step 5/6 — API Gateway (REST + WebSocket)"
aws cloudformation deploy \
  --template-file "$CFN_DIR/05-api.yaml" \
  --stack-name "${PROJECT}-central-api" \
  --parameter-overrides ProjectName="$PROJECT" \
  $DEPLOY_FLAGS
echo "  ✓ API stack deployed"
echo ""

# ── STACK 6 — DASHBOARD + FINALIZATION ────────────────────────────────────
echo "Step 6/6 — Dashboard config and schedule activation"
aws cloudformation deploy \
  --template-file "$CFN_DIR/06-dashboard.yaml" \
  --stack-name "${PROJECT}-central-dashboard" \
  --parameter-overrides ProjectName="$PROJECT" \
  --capabilities CAPABILITY_IAM \
  $DEPLOY_FLAGS
echo "  ✓ Dashboard stack deployed"
echo ""

# ── UPLOAD RUNBOOKS ────────────────────────────────────────────────────────
echo "Uploading runbooks to S3..."
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
RUNBOOKS_BUCKET="${PROJECT}-runbooks-${ACCOUNT_ID}"
RUNBOOKS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../runbooks" && pwd)"

aws s3 sync "$RUNBOOKS_DIR" "s3://$RUNBOOKS_BUCKET/runbooks/" \
  --include "*.md" --quiet
echo "  ✓ Runbooks uploaded"
echo ""

# ── PRINT OUTPUTS ─────────────────────────────────────────────────────────
echo "╔══════════════════════════════════════════════════╗"
echo "║  Deployment Complete — Endpoints                 ║"
echo "╠══════════════════════════════════════════════════╣"

REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text)

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text)

DASHBOARD_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text)

echo "║  REST API   : $REST_URL"
echo "║  WebSocket  : $WS_URL"
echo "║  Dashboard  : $DASHBOARD_URL"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Next step: deploy simulation stack"
echo "  cd ../../simulation/scripts && ./deploy-simulation.sh"
echo ""
echo "Set these for the dashboard build:"
echo "  export VITE_API_URL=$REST_URL"
echo "  export VITE_WS_URL=$WS_URL"

# ── WRITE DASHBOARD .env.local ─────────────────────────────────────────────
# So "npm run dev" works immediately after deploy without manual env var setting
REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text 2>/dev/null) || REST_URL=""

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text 2>/dev/null) || WS_URL=""

ENV_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../dashboard" && pwd)/.env.local"
cat > "$ENV_FILE" << ENVEOF
VITE_API_URL=$REST_URL
VITE_WS_URL=$WS_URL
ENVEOF
echo "  ✓ Dashboard .env.local written → $ENV_FILE"
echo "    To start dashboard: cd dashboard && npm run dev"
echo "    Then open: http://localhost:5173"

# ── PRINT CLOUDFRONT URL ───────────────────────────────────────────────────
CF_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text 2>/dev/null) || CF_URL="(check CloudFormation outputs)"

REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text 2>/dev/null) || REST_URL=""

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text 2>/dev/null) || WS_URL=""

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Central Deployment Complete                    ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  REST API   : $REST_URL"
echo "║  WebSocket  : $WS_URL"
echo "║  Dashboard  : $CF_URL"
echo "╠══════════════════════════════════════════════════╣"
echo "║  Next: deploy simulation, then build dashboard  ║"
echo "║    ./simulation/scripts/deploy-simulation.sh    ║"
echo "║    cd dashboard && ./build.sh                   ║"
echo "╚══════════════════════════════════════════════════╝"
