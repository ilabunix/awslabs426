#!/usr/bin/env bash
# OpsIQ Dashboard — Build & Deploy to S3 + CloudFront invalidation
# Node.js must be installed. Download from https://nodejs.org (LTS)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT="${PROJECT:-opsiq}"
REGION="${REGION:-us-west-2}"

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ Dashboard — Build & Deploy               ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# ── FETCH ENDPOINTS FROM CFN ──────────────────────────────────────────
echo "Fetching endpoints from CloudFormation..."

REST_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='RestAPIEndpoint'].OutputValue" \
  --output text 2>/dev/null) || { echo "ERROR: central-api stack not found"; exit 1; }

WS_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-api" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='WebSocketEndpoint'].OutputValue" \
  --output text 2>/dev/null) || WS_URL=""

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
DASHBOARD_BUCKET="${PROJECT}-dashboard-${ACCOUNT_ID}"

DIST_ID=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardDistributionId'].OutputValue" \
  --output text 2>/dev/null) || DIST_ID=""

CF_URL=$(aws cloudformation describe-stacks \
  --stack-name "${PROJECT}-central-storage" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='DashboardURL'].OutputValue" \
  --output text 2>/dev/null) || CF_URL=""

echo "  REST API      : $REST_URL"
echo "  WebSocket     : $WS_URL"
echo "  S3 Bucket     : $DASHBOARD_BUCKET"
echo "  Distribution  : $DIST_ID"
echo ""

# ── INSTALL & BUILD ───────────────────────────────────────────────────
echo "Installing npm dependencies..."
cd "$SCRIPT_DIR"
npm install --silent
echo "  ✓ Done"
echo ""

echo "Building React app..."
VITE_API_URL="$REST_URL" \
VITE_WS_URL="$WS_URL" \
npm run build
echo "  ✓ Build complete → dist/"
echo ""

# ── UPLOAD TO S3 ──────────────────────────────────────────────────────
echo "Uploading to S3..."

# Hashed assets — long cache
aws s3 sync dist/ "s3://$DASHBOARD_BUCKET/" \
  --region "$REGION" \
  --delete \
  --exclude "index.html" \
  --cache-control "public, max-age=31536000, immutable" \
  --quiet

# index.html — no cache so CloudFront always fetches latest
aws s3 cp dist/index.html "s3://$DASHBOARD_BUCKET/index.html" \
  --region "$REGION" \
  --cache-control "no-cache, no-store, must-revalidate" \
  --content-type "text/html" \
  --quiet

echo "  ✓ Uploaded"

# ── INVALIDATE CLOUDFRONT CACHE ───────────────────────────────────────
if [[ -n "$DIST_ID" ]]; then
  echo ""
  echo "Invalidating CloudFront cache..."
  aws cloudfront create-invalidation \
    --distribution-id "$DIST_ID" \
    --paths "/*" \
    --query 'Invalidation.Id' \
    --output text
  echo "  ✓ Invalidation created (takes ~30 seconds to propagate)"
fi

# ── DONE ──────────────────────────────────────────────────────────────
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Dashboard Deployed                              ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  URL: $CF_URL"
echo "║                                                  ║"
echo "║  Note: CloudFront may take 2-3 min to           ║"
echo "║  propagate on first deploy.                     ║"
echo "╚══════════════════════════════════════════════════╝"
