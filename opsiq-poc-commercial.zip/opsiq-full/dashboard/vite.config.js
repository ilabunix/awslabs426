import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'dist',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          react:  ['react', 'react-dom'],
          d3:     ['d3'],
          zustand:['zustand'],
        },
      },
    },
  },
  // VITE_API_URL and VITE_WS_URL are set from CFN outputs at build time
  // e.g. VITE_API_URL=https://xxx.execute-api.us-west-2.amazonaws.com/poc
});
