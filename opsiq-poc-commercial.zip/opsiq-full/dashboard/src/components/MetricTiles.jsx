import { useStore } from '../store.js';

function Sparkline({ points, color }) {
  const w = 80, h = 24;
  const max = Math.max(...points, 1);
  const coords = points.map((v, i) => {
    const x = (i / (points.length - 1)) * w;
    const y = h - (v / max) * (h - 2) - 1;
    return `${x},${y}`;
  }).join(' ');
  const area = `0,${h} ${coords} ${w},${h}`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} style={{ width: '100%', height: 24, marginTop: 6 }}>
      <defs>
        <linearGradient id={`sg-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".3"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polygon points={area} fill={`url(#sg-${color.replace('#','')})`}/>
      <polyline points={coords} fill="none" stroke={color} strokeWidth="1.6"/>
    </svg>
  );
}

export default function MetricTiles() {
  const accounts  = useStore(s => s.accounts);
  const incidents = useStore(s => s.incidents);
  const anomalies = useStore(s => s.anomalies);

  const accountCount = accounts.length;
  const incidentCount = incidents.filter(i => i.status === 'OPEN').length;
  const anomalyCount = anomalies.length;
  const avgScore = accounts.length
    ? Math.round(accounts.reduce((a, b) => a + (b.score || 0), 0) / accounts.length)
    : 0;

  const tiles = [
    {
      label: 'Accounts Monitored',
      value: accountCount,
      color: 'var(--blue)',
      delta: { text: 'AWS us-west-2', cls: 'flat' },
      spark: [3, 3, 3, 3, 3],
      sparkColor: '#0972D3',
    },
    {
      label: 'Active Incidents',
      value: incidentCount,
      color: incidentCount > 0 ? 'var(--red)' : 'var(--green)',
      delta: incidentCount > 0
        ? { text: `${incidentCount} open`, cls: 'bad', arrow: 'up' }
        : { text: 'All clear', cls: 'good' },
      spark: [0, 0, 1, 1, 2, 3, incidentCount],
      sparkColor: '#D13212',
    },
    {
      label: 'Anomalies (30 min)',
      value: anomalyCount,
      color: anomalyCount > 5 ? 'var(--amber)' : 'var(--green)',
      delta: anomalyCount > 5
        ? { text: `${anomalyCount} detected`, cls: 'bad', arrow: 'up' }
        : { text: 'Normal range', cls: 'good' },
      spark: [1, 2, 2, 3, 5, 8, anomalyCount],
      sparkColor: '#946600',
    },
    {
      label: 'Avg Health Score',
      value: avgScore,
      color: avgScore >= 80 ? 'var(--green)' : avgScore >= 60 ? 'var(--amber)' : 'var(--red)',
      delta: { text: 'Across all accounts', cls: 'flat' },
      spark: [95, 92, 90, 85, 80, 76, avgScore],
      sparkColor: '#067940',
    },
  ];

  return (
    <div className="metric-grid">
      {tiles.map((tile, i) => (
        <div className="metric-tile fade-in" key={tile.label} style={{ animationDelay: `${i * 0.05}s` }}>
          <div className="mt-label">{tile.label}</div>
          <div className="mt-value" style={{ color: tile.color }}>{tile.value}</div>
          <div className={`mt-delta ${tile.delta.cls}`}>
            {tile.delta.arrow === 'up' && (
              <svg viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M5 8V2M2 5l3-3 3 3"/>
              </svg>
            )}
            {tile.delta.text}
          </div>
          <Sparkline points={tile.spark} color={tile.sparkColor} />
        </div>
      ))}
    </div>
  );
}
