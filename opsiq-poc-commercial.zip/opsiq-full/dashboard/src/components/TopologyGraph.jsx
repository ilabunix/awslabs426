import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { useStore } from '../store.js';

const STATUS_COLOR = {
  critical: '#D13212',
  warning:  '#946600',
  healthy:  '#067940',
  default:  '#8A8A8A',
};

const TIER_COLOR = {
  ingress: '#0972D3',
  compute: '#D13212',
  data:    '#946600',
  storage: '#067940',
  other:   '#8A8A8A',
};

export default function TopologyGraph() {
  const svgRef = useRef(null);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const topology = useStore(s => s.topology);
  const graph = topology[selectedAccountId];

  useEffect(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    if (!graph || !graph.nodes?.length) {
      svg.append('text')
        .attr('x', '50%').attr('y', '50%')
        .attr('text-anchor', 'middle').attr('dominant-baseline', 'middle')
        .attr('fill', '#8A8A8A').attr('font-size', 13).attr('font-family', 'Noto Sans, sans-serif')
        .text(selectedAccountId ? 'Loading topology…' : 'Select an account');
      return;
    }

    const W = svgRef.current.clientWidth || 520;
    const H = 220;

    // D3 force simulation
    const nodes = graph.nodes.map(n => ({ ...n }));
    const edges = graph.edges.map(e => ({ ...e }));

    const sim = d3.forceSimulation(nodes)
      .force('link',   d3.forceLink(edges).id(d => d.id).distance(100))
      .force('charge', d3.forceManyBody().strength(-200))
      .force('center', d3.forceCenter(W / 2, H / 2))
      .force('y',      d3.forceY(H / 2).strength(0.05))
      .stop();

    // Run simulation synchronously for static render
    for (let i = 0; i < 200; i++) sim.tick();

    const g = svg.append('g');

    // Zoom + pan
    svg.call(d3.zoom().scaleExtent([0.5, 2]).on('zoom', e => {
      g.attr('transform', e.transform);
    }));

    // Arrow marker
    svg.append('defs').append('marker')
      .attr('id', 'arrow')
      .attr('viewBox', '0 0 8 8')
      .attr('refX', 6).attr('refY', 4)
      .attr('markerWidth', 5).attr('markerHeight', 5)
      .attr('orient', 'auto')
      .append('path')
        .attr('d', 'M0,0 L0,8 L8,4 z')
        .attr('fill', '#8A8A8A');

    // Edges
    g.selectAll('line.edge')
      .data(edges).enter()
      .append('line')
        .attr('class', 'edge')
        .attr('x1', d => d.source.x).attr('y1', d => d.source.y)
        .attr('x2', d => d.target.x).attr('y2', d => d.target.y)
        .attr('stroke', '#C0C0C0').attr('stroke-width', 1.2)
        .attr('marker-end', 'url(#arrow)');

    // Node groups
    const nodeG = g.selectAll('g.node')
      .data(nodes).enter()
      .append('g')
        .attr('class', 'node')
        .attr('transform', d => `translate(${d.x},${d.y})`)
        .style('cursor', 'pointer');

    // Node card background
    const cardW = 88, cardH = 44;
    nodeG.append('rect')
      .attr('x', -cardW / 2).attr('y', -cardH / 2)
      .attr('width', cardW).attr('height', cardH)
      .attr('rx', 4)
      .attr('fill', '#FFFFFF')
      .attr('stroke', d => TIER_COLOR[d.tier] || '#D1D5DB')
      .attr('stroke-width', 1.2)
      .attr('filter', 'drop-shadow(0 1px 3px rgba(0,0,0,0.12))');

    // Top color stripe
    nodeG.append('rect')
      .attr('x', -cardW / 2).attr('y', -cardH / 2)
      .attr('width', cardW).attr('height', 3)
      .attr('rx', 4)
      .attr('fill', d => TIER_COLOR[d.tier] || '#8A8A8A');

    // Node label (name)
    nodeG.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', -6)
      .attr('font-size', 9.5)
      .attr('font-weight', '700')
      .attr('font-family', 'Noto Sans, sans-serif')
      .attr('fill', '#0F1111')
      .text(d => (d.label || d.id).slice(0, 14));

    // Node label (type)
    nodeG.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', 7)
      .attr('font-size', 8.5)
      .attr('font-family', 'Noto Sans, sans-serif')
      .attr('fill', '#565959')
      .text(d => {
        const t = d.type || '';
        return t.replace('aws_', '').replace(/_/g, ' ').slice(0, 16);
      });

    // Tier badge
    nodeG.append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', 18)
      .attr('font-size', 8)
      .attr('font-family', "'Source Code Pro', monospace")
      .attr('fill', d => TIER_COLOR[d.tier] || '#8A8A8A')
      .text(d => d.tier || '');

    // Hover effect
    nodeG.on('mouseover', function() {
      d3.select(this).select('rect').attr('stroke-width', 2);
    }).on('mouseout', function() {
      d3.select(this).select('rect').attr('stroke-width', 1.2);
    });

  }, [graph, selectedAccountId]);

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Infrastructure Topology — {selectedAccountId || '—'}</div>
          <div className="panel-sub">
            {graph ? `${graph.nodeCount || 0} resources · ${graph.edgeCount || 0} edges` : 'Select an account'}
            {graph && ' · Scroll to zoom · Drag to pan'}
          </div>
        </div>
        <a className="panel-link">Full view →</a>
      </div>
      <div style={{ background: '#FAFAFA', padding: 16 }}>
        <svg
          ref={svgRef}
          style={{ width: '100%', height: 220, display: 'block', overflow: 'visible' }}
        />
      </div>
    </div>
  );
}
