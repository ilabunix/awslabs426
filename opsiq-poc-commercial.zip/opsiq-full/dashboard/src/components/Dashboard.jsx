import { useStore }     from '../store.js';
import MetricTiles      from './MetricTiles.jsx';
import AccountTable     from './AccountTable.jsx';
import TopologyGraph    from './TopologyGraph.jsx';
import AIPanel          from './AIPanel.jsx';
import {
  SignalFeed,
  IncidentTable,
  DriftPanel,
  AlertBanner,
} from './SignalFeed.jsx';

export default function Dashboard() {
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const fetchAll = useStore(s => s.fetchAll);

  return (
    <div className="content">
      {/* Breadcrumb */}
      <div className="breadcrumb">
        <a href="#">OpsIQ</a>
        <svg viewBox="0 0 6 10" fill="currentColor"><path d="M1 1l4 4-4 4" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>
        Dashboard
      </div>

      {/* Page header */}
      <div className="page-hdr">
        <div>
          <div className="page-title-row">
            <h1 className="page-title">Operations Dashboard</h1>
          </div>
          <div className="page-desc">
            AWS Commercial · us-west-2 · Auto-refreshes every 30 seconds
          </div>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary" style={{ fontSize: 12.5 }}>
            <svg viewBox="0 0 24 24"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
            Last 30 min
          </button>
          <button className="btn btn-secondary" style={{ fontSize: 12.5 }} onClick={fetchAll}>
            <svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
            Refresh
          </button>
          <button
            className="btn btn-primary"
            style={{ fontSize: 12.5 }}
            onClick={() => {
              // Invoke anomaly injector via the API
              fetch(`${import.meta.env.VITE_API_URL || ''}/demo/inject`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ scenario: 'ecs-oom', accountId: 'sim-app-a' }),
              }).catch(() => {});
            }}
          >
            <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            Run Demo Scenario
          </button>
        </div>
      </div>

      {/* Alert banner — shows when accounts are in critical state */}
      <AlertBanner />

      {/* KPI metric tiles */}
      <MetricTiles />

      {/* Account health table */}
      <AccountTable />

      {/* Two-column lower section */}
      <div className="two-col">

        {/* Left — signal feed + topology */}
        <div>
          <SignalFeed />
          <TopologyGraph />
        </div>

        {/* Right — incidents + AI + drift */}
        <div>
          <IncidentTable />
          <AIPanel />
          <DriftPanel accountId={selectedAccountId} />
        </div>

      </div>
    </div>
  );
}
