import { useEffect } from 'react';
import { useStore } from '../store.js';

function scoreColor(score) {
  if (score >= 80) return 'var(--green)';
  if (score >= 60) return 'var(--amber)';
  return 'var(--red)';
}

function StatusBadge({ score }) {
  if (score >= 80) return <span className="badge badge-green">Healthy</span>;
  if (score >= 60) return <span className="badge badge-amber">Warning</span>;
  return <span className="badge badge-red">Critical</span>;
}

export default function AccountTable() {
  const accounts  = useStore(s => s.accounts);
  const anomalies = useStore(s => s.anomalies);
  const incidents = useStore(s => s.incidents);
  const selectedAccountId = useStore(s => s.selectedAccountId);
  const setSelectedAccount = useStore(s => s.setSelectedAccount);
  const fetchTopology = useStore(s => s.fetchTopology);
  const loading = useStore(s => s.loading.accounts);

  // When an account is selected, fetch its topology
  useEffect(() => {
    if (selectedAccountId) fetchTopology(selectedAccountId);
  }, [selectedAccountId]);

  const sorted = [...accounts].sort((a, b) => (a.score || 0) - (b.score || 0));

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Account Health</div>
          <div className="panel-sub">{accounts.length} accounts · AWS us-west-2</div>
        </div>
        <div className="panel-actions">
          <button className="btn btn-secondary" style={{ fontSize: 12, padding: '5px 12px' }}>
            Actions
            <svg viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.5" style={{ width: 11, height: 11 }}>
              <path d="M2 4l4 4 4-4"/>
            </svg>
          </button>
        </div>
      </div>

      {loading ? (
        <div className="loading-row">
          <span className="spinner" />Loading accounts…
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table className="aws-table">
            <thead>
              <tr>
                <th>Account</th>
                <th>Stack</th>
                <th>Health Score</th>
                <th>Incidents</th>
                <th>Anomalies</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map(acc => {
                const accIncidents = incidents.filter(i => i.accountId === acc.accountId && i.status === 'OPEN').length;
                const accAnomalies = anomalies.filter(a => a.accountId === acc.accountId).length;
                const color = scoreColor(acc.score || 0);
                const isSelected = acc.accountId === selectedAccountId;

                return (
                  <tr
                    key={acc.accountId}
                    className={isSelected ? 'selected' : ''}
                    style={{ cursor: 'pointer' }}
                    onClick={() => setSelectedAccount(acc.accountId)}
                  >
                    <td>
                      <div style={{ fontWeight: 600 }}>{acc.accountId}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-mono)' }}>
                        arn:aws:…:{acc.accountId}
                      </div>
                    </td>
                    <td>
                      <span style={{ fontSize: 12.5, color: 'var(--text-2)' }}>
                        {acc.accountId === 'sim-app-a' && 'ECS · ALB · Aurora'}
                        {acc.accountId === 'sim-app-b' && 'Lambda · APIGW · DDB'}
                        {acc.accountId === 'sim-app-c' && 'ECS · ALB · Redis'}
                        {!['sim-app-a','sim-app-b','sim-app-c'].includes(acc.accountId) && 'AWS Managed'}
                      </span>
                    </td>
                    <td>
                      <div className="score-bar-wrap">
                        <div className="score-bar-bg">
                          <div
                            className="score-bar-fill"
                            style={{ width: `${acc.score || 0}%`, background: color }}
                          />
                        </div>
                        <span className="score-num" style={{ color }}>{acc.score ?? '—'}</span>
                      </div>
                    </td>
                    <td>
                      <span style={{ fontWeight: 700, color: accIncidents > 0 ? 'var(--red)' : 'var(--text-3)' }}>
                        {accIncidents}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontWeight: 700, color: accAnomalies > 3 ? 'var(--amber)' : 'var(--text-3)' }}>
                        {accAnomalies}
                      </span>
                    </td>
                    <td><StatusBadge score={acc.score || 0} /></td>
                    <td>
                      <button className="btn btn-link" style={{ fontSize: 12.5 }}
                        onClick={e => { e.stopPropagation(); setSelectedAccount(acc.accountId); }}>
                        View details
                      </button>
                    </td>
                  </tr>
                );
              })}
              {sorted.length === 0 && (
                <tr><td colSpan={7} className="empty-state">No accounts found. Run deploy-simulation.sh to seed data.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
