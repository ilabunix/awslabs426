import { useState } from 'react';
import { useStore } from '../store.js';

export default function TopNav() {
  const [activeTab, setActiveTab] = useState('Dashboard');
  const fetchAll = useStore(s => s.fetchAll);
  const lastRefreshed = useStore(s => s.lastRefreshed);

  const timeStr = lastRefreshed
    ? lastRefreshed.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'UTC' }) + ' UTC'
    : '—';

  return (
    <nav className="top-nav">
      {/* Brand */}
      <a className="nav-brand">
        <div className="nav-logo-box">
          <svg viewBox="0 0 24 24" fill="none">
            <path d="M6 20Q12 24 18 20" stroke="#FF9900" strokeWidth="2.2" strokeLinecap="round"/>
            <path d="M4 11L12 7L20 11" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M4 11L12 15L20 11" stroke="white" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" opacity=".6"/>
          </svg>
        </div>
        <span className="nav-product-name">Ops<span>IQ</span></span>
      </a>

      {/* Nav tabs */}
      {['Dashboard', 'Accounts', 'Incidents', 'Runbooks'].map(tab => (
        <button
          key={tab}
          className={`nav-tab${activeTab === tab ? ' active' : ''}`}
          onClick={() => setActiveTab(tab)}
        >
          {tab}
          {tab === 'Accounts' || tab === 'Incidents' ? (
            <svg viewBox="0 0 12 12" fill="currentColor"><path d="M2 4l4 4 4-4z"/></svg>
          ) : null}
        </button>
      ))}

      <div className="nav-sp" />

      {/* Right side */}
      <div className="nav-right">
        <button className="region-pill">
          <span className="region-dot" />
          us-west-2
          <svg viewBox="0 0 12 12" width="10" height="10" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M2 4l4 4 4-4"/></svg>
        </button>

        <button className="nav-r-btn" title={`Last refreshed: ${timeStr}`} onClick={fetchAll}>
          <svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10"/></svg>
          {timeStr}
        </button>

        <button className="nav-r-btn">
          <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/></svg>
          Alerts
        </button>

        <button className="nav-r-btn">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 10-16 0"/></svg>
          Irshad L.
        </button>
      </div>
    </nav>
  );
}
