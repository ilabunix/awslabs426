// ─── SignalFeed.jsx ───────────────────────────────────────────────────────
import { useStore } from '../store.js';

export function SignalFeed() {
  const anomalies = useStore(s => s.anomalies);
  const accounts  = useStore(s => s.accounts);

  // Build sparkline data per account from anomaly counts
  const accountSparklines = accounts.map(acc => {
    const count = anomalies.filter(a => a.accountId === acc.accountId).length;
    return { id: acc.accountId, score: acc.score || 0, count };
  });

  function dotClass(sev) {
    if (sev === 'HIGH')   return 'sd-red';
    if (sev === 'MEDIUM') return 'sd-amber';
    return 'sd-blue';
  }

  function timeAgo(tsMs) {
    if (!tsMs) return '';
    const diff = Date.now() - Number(tsMs);
    const min  = Math.floor(diff / 60000);
    if (min < 1)  return 'just now';
    if (min < 60) return `${min} min ago`;
    return `${Math.floor(min / 60)}h ago`;
  }

  // Build metric rows from latest anomaly data
  const metricRows = [
    { label: 'ECS Memory Util %',    val: '98.7%',   valColor: 'var(--red)',   points: [40,45,50,60,72,85,98] },
    { label: 'ALB 5xx Rate %',       val: '28.5%',   valColor: 'var(--amber)', points: [0.3,0.5,1,3,8,18,28] },
    { label: 'Lambda P99 ms',        val: '14,987',  valColor: 'var(--amber)', points: [200,300,500,1200,5000,10000,14987] },
    { label: 'RDS Connections',      val: '98/100',  valColor: 'var(--red)',   points: [20,30,40,55,70,85,98] },
    { label: 'sim-app-c Redis ms',   val: '38ms',    valColor: 'var(--green)', points: [42,40,39,38,38,37,38] },
  ];

  const sparkColors = ['#D13212','#946600','#946600','#D13212','#067940'];

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Signal Feed</div>
          <div className="panel-sub">Latest anomaly detections · Last 30 min</div>
        </div>
        <a className="panel-link">View all signals →</a>
      </div>
      <div className="panel-body" style={{ paddingTop: 8, paddingBottom: 8 }}>

        {/* Sparkline rows */}
        {metricRows.map((row, i) => {
          const w = 160, h = 28, max = Math.max(...row.points, 1);
          const pts = row.points.map((v, j) => {
            const x = (j / (row.points.length - 1)) * w;
            const y = h - (v / max) * (h - 3) - 1;
            return `${x},${y}`;
          }).join(' ');
          const area = `0,${h} ${pts} ${w},${h}`;
          const uid = `sg${i}`;
          return (
            <div className="spark-row" key={row.label}>
              <div className="spark-label">{row.label}</div>
              <svg className="spark-svg" viewBox={`0 0 ${w} ${h}`} height={h}>
                <defs>
                  <linearGradient id={uid} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={sparkColors[i]} stopOpacity=".25"/>
                    <stop offset="100%" stopColor={sparkColors[i]} stopOpacity="0"/>
                  </linearGradient>
                </defs>
                <polygon points={area} fill={`url(#${uid})`}/>
                <polyline points={pts} fill="none" stroke={sparkColors[i]} strokeWidth="1.6"/>
              </svg>
              <div className="spark-val" style={{ color: row.valColor }}>{row.val}</div>
            </div>
          );
        })}

        <div style={{ borderTop: '1px solid var(--border-light)', margin: '10px 0' }} />

        {/* Anomaly items */}
        {anomalies.slice(0, 6).map((a, i) => (
          <div className="signal-item" key={i}>
            <div className={`signal-dot ${dotClass(a.severity)}`} />
            <div className="signal-body">
              <div className="signal-title">
                {a.anomalyType?.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}
                {a.metric && ` — ${a.value ?? ''}${a.unit ?? ''}`}
              </div>
              <div className="signal-detail">
                {a.resource || a.logGroup || a.description || '—'}
              </div>
              {a.signature && (
                <div className="signal-meta" style={{ color: 'var(--purple)', fontStyle: 'italic' }}>
                  Novel pattern · Bloom filter: first occurrence
                </div>
              )}
            </div>
            <div className="signal-time">{timeAgo(a.timestamp)}</div>
          </div>
        ))}

        {anomalies.length === 0 && (
          <div className="empty-state" style={{ padding: '20px 0' }}>
            No anomalies in the last 30 minutes. System appears healthy.
          </div>
        )}
      </div>
    </div>
  );
}

// ─── IncidentTable.jsx ────────────────────────────────────────────────────
export function IncidentTable() {
  const incidents = useStore(s => s.incidents);
  const open = incidents.filter(i => i.status === 'OPEN');
  const highCount = open.filter(i => i.severity === 'HIGH').length;
  const medCount  = open.filter(i => i.severity === 'MEDIUM').length;

  function timeAgo(tsMs) {
    if (!tsMs) return '';
    const diff = Date.now() - Number(tsMs);
    const min = Math.floor(diff / 60000);
    if (min < 1)  return 'just now';
    if (min < 60) return `${min} min`;
    return `${Math.floor(min / 60)}h`;
  }

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Open Incidents</div>
          <div className="panel-sub">
            {open.length} active
            {highCount > 0 && ` · ${highCount} HIGH`}
            {medCount > 0  && ` · ${medCount} MED`}
          </div>
        </div>
        <a className="panel-link">View all</a>
      </div>
      <div style={{ overflowX: 'auto' }}>
        <table className="aws-table">
          <thead>
            <tr>
              <th>Severity</th>
              <th>Summary</th>
              <th>Account</th>
              <th>Age</th>
            </tr>
          </thead>
          <tbody>
            {open.map(inc => (
              <tr key={inc.incidentId} style={{ cursor: 'pointer' }}>
                <td>
                  <span className={`sev sev-${inc.severity?.[0] || 'L'}`}>
                    {inc.severity}
                  </span>
                </td>
                <td>
                  <div style={{ fontWeight: 500, fontSize: 12.5 }}>
                    {inc.aiSummary?.headline || inc.incidentType?.replace(/_/g, ' ') || 'Incident detected'}
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 1 }}>
                    {inc.signalCount} signal{inc.signalCount !== 1 ? 's' : ''}
                    {inc.aiSummary && <span style={{ color: 'var(--purple)', marginLeft: 6 }}>· AI summary ready</span>}
                  </div>
                </td>
                <td style={{ fontSize: 12.5, color: 'var(--text-2)' }}>{inc.accountId}</td>
                <td style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-3)', whiteSpace: 'nowrap' }}>
                  {timeAgo(inc.timestamp)}
                </td>
              </tr>
            ))}
            {open.length === 0 && (
              <tr><td colSpan={4} className="empty-state">No open incidents. All clear.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── DriftPanel.jsx ───────────────────────────────────────────────────────
export function DriftPanel({ accountId }) {
  // Static drift data matching simulation — in production this comes from drift-detector Lambda
  const drifts = accountId === 'sim-app-a' ? [
    { type: 'UNMANAGED', name: 'temp-sg-debug',  resourceType: 'aws_security_group',   detail: 'Created manually during incident — not in Terraform state' },
    { type: 'MISSING',   name: 'backup-lambda',  resourceType: 'aws_lambda_function',  detail: 'Present in tfstate but not found in account' },
  ] : accountId === 'sim-app-b' ? [
    { type: 'UNMANAGED', name: 'test-dynamodb-table', resourceType: 'aws_dynamodb_table', detail: 'Created by developer for testing, never added to tfstate' },
  ] : accountId === 'sim-app-c' ? [
    { type: 'MISSING', name: 'redis-replica', resourceType: 'aws_elasticache_cluster', detail: 'Removed from config but not deleted from account' },
  ] : [];

  return (
    <div className="panel fade-in">
      <div className="panel-hdr">
        <div>
          <div className="panel-title">Drift Detection</div>
          <div className="panel-sub">{accountId || '—'} · Checked 6h ago</div>
        </div>
        {drifts.length > 0
          ? <span className="badge badge-amber">{drifts.length} drift{drifts.length !== 1 ? 's' : ''}</span>
          : <span className="badge badge-green">No drift</span>
        }
      </div>
      <div className="panel-body" style={{ paddingTop: 4, paddingBottom: 4 }}>
        {drifts.map((d, i) => (
          <div className="drift-row" key={i}>
            <span className={`drift-tag ${d.type === 'UNMANAGED' ? 'dt-unmanaged' : 'dt-missing'}`}>
              {d.type}
            </span>
            <div>
              <div className="drift-name">
                {d.name}
                <span className="drift-chip">{d.resourceType}</span>
              </div>
              <div className="drift-detail">{d.detail}</div>
            </div>
          </div>
        ))}
        {drifts.length === 0 && (
          <div className="empty-state" style={{ padding: '16px 0' }}>
            No infrastructure drift detected for this account.
          </div>
        )}
      </div>
    </div>
  );
}

// ─── AlertBanner.jsx ──────────────────────────────────────────────────────
export function AlertBanner() {
  const accounts = useStore(s => s.accounts);
  const critical = accounts.filter(a => (a.score || 0) < 60);
  if (critical.length === 0) return null;

  return (
    <div className="alert alert-amber">
      <svg viewBox="0 0 24 24">
        <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
        <line x1="12" y1="9" x2="12" y2="13"/>
        <line x1="12" y1="17" x2="12.01" y2="17"/>
      </svg>
      <div>
        <div className="alert-title">
          {critical.length} account{critical.length > 1 ? 's' : ''} in critical state
        </div>
        <div className="alert-body">
          {critical.map(a => a.accountId).join(', ')} — health score below 60.
          Infrastructure drift also detected.{' '}
          <a className="alert-link" href="#">Review now →</a>
        </div>
      </div>
    </div>
  );
}
