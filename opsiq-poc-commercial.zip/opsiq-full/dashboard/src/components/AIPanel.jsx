import { useStore } from '../store.js';

export default function AIPanel() {
  const incidents = useStore(s => s.incidents);
  const selectedAccountId = useStore(s => s.selectedAccountId);

  // Find the most recent HIGH incident with an AI summary for the selected account
  const incident = incidents.find(i =>
    i.accountId === selectedAccountId &&
    i.status === 'OPEN' &&
    i.severity === 'HIGH' &&
    i.aiSummary
  ) || incidents.find(i =>
    i.accountId === selectedAccountId &&
    i.status === 'OPEN'
  );

  const summary = incident?.aiSummary;

  if (!incident) {
    return (
      <div className="panel fade-in">
        <div className="panel-hdr">
          <div className="panel-title" style={{ color: 'var(--purple)' }}>
            Amazon Bedrock — AI Incident Analysis
          </div>
        </div>
        <div className="panel-body empty-state">
          No open incidents for the selected account.
        </div>
      </div>
    );
  }

  return (
    <div className="ai-panel fade-in" style={{ marginBottom: 16 }}>
      <div className="ai-panel-hdr">
        <svg className="ai-panel-hdr-icon" viewBox="0 0 24 24">
          <path d="M12 2a10 10 0 110 20A10 10 0 0112 2zm0 5a1 1 0 00-1 1v4a1 1 0 002 0V8a1 1 0 00-1-1zm0 8a1 1 0 100 2 1 1 0 000-2z"/>
        </svg>
        <span className="ai-panel-title">Amazon Bedrock — AI Incident Analysis</span>
        <span className="ai-panel-sub">
          Claude Sonnet · {incident.signalCount} signal{incident.signalCount !== 1 ? 's' : ''}
        </span>
      </div>

      <div className="ai-panel-body">
        <div className="ai-headline">
          {summary?.headline || `${incident.incidentType?.replace(/_/g, ' ')} detected in ${incident.accountId}`}
        </div>

        {summary?.investigationSteps?.length > 0 && (
          <ol className="ai-steps">
            {summary.investigationSteps.slice(0, 4).map((step, i) => (
              <li key={i}>
                <span className="ai-step-num">{i + 1}</span>
                <span>
                  {step.split(/(`[^`]+`)/).map((part, j) =>
                    part.startsWith('`') && part.endsWith('`')
                      ? <span key={j} className="code-chip">{part.slice(1, -1)}</span>
                      : part
                  )}
                </span>
              </li>
            ))}
          </ol>
        )}

        {!summary && (
          <div style={{ color: 'var(--text-3)', fontSize: 12.5, marginTop: 8 }}>
            <span className="spinner" />
            AI analysis in progress…
          </div>
        )}

        <div className="ai-footer">
          {summary?.confidence || 'MEDIUM'} confidence
          {summary?.runbookReference?.section && ` · Runbook: ${summary.runbookReference.section}`}
        </div>
      </div>
    </div>
  );
}
