import { useEffect } from 'react';
import { useStore } from './store.js';
import TopNav    from './components/TopNav.jsx';
import Sidebar   from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';

export default function App() {
  const init = useStore(s => s.init);

  useEffect(() => {
    const cleanup = init();
    return cleanup;
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <TopNav />
      <div className="shell">
        <Sidebar />
        <main className="main-area">
          <Dashboard />
        </main>
      </div>
    </div>
  );
}
