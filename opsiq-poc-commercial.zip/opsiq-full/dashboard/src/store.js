/**
 * OpsIQ Dashboard — Global State (Zustand)
 * Single store for all dashboard data.
 * WebSocket events are merged in via mergeEvent().
 */
import { create } from 'zustand';
import { api, connectWebSocket, subscribeToEvents } from './api.js';

export const useStore = create((set, get) => ({

  // ── DATA ────────────────────────────────────────────────────────────────
  accounts:      [],   // [{ accountId, score, calculatedAt }]
  incidents:     [],   // [{ incidentId, accountId, severity, ... }]
  anomalies:     [],   // most recent 50 across all accounts
  topology:      {},   // { [accountId]: { nodes, edges } }
  selectedAccountId: null,

  // ── LOADING STATE ────────────────────────────────────────────────────────
  loading: {
    accounts: false,
    incidents: false,
    anomalies: false,
  },
  lastRefreshed: null,

  // ── ACTIONS ─────────────────────────────────────────────────────────────

  setSelectedAccount: (id) => set({ selectedAccountId: id }),

  fetchAll: async () => {
    set({ loading: { accounts: true, incidents: true, anomalies: true } });
    try {
      const [accountsRes, incidentsRes] = await Promise.all([
        api.getAccounts(),
        api.getAllIncidents(),
      ]);

      const accounts  = accountsRes.accounts  || [];
      const incidents = incidentsRes.incidents || [];

      // Fetch anomalies for each account (parallel)
      const anomalyResults = await Promise.all(
        accounts.map(a => api.getAnomalies(a.accountId).catch(() => ({ anomalies: [] })))
      );
      const anomalies = anomalyResults
        .flatMap(r => r.anomalies || [])
        .sort((a, b) => (b.timestamp || '').localeCompare(a.timestamp || ''))
        .slice(0, 50);

      set({
        accounts,
        incidents,
        anomalies,
        loading: { accounts: false, incidents: false, anomalies: false },
        lastRefreshed: new Date(),
      });

      // Set default selected account to the lowest-scoring one
      if (accounts.length && !get().selectedAccountId) {
        const worst = accounts.reduce((a, b) => (a.score < b.score ? a : b));
        set({ selectedAccountId: worst.accountId });
      }
    } catch (e) {
      console.error('fetchAll failed', e);
      set({ loading: { accounts: false, incidents: false, anomalies: false } });
    }
  },

  fetchTopology: async (accountId) => {
    try {
      const data = await api.getTopology(accountId);
      set(state => ({ topology: { ...state.topology, [accountId]: data } }));
    } catch (e) {
      console.error(`fetchTopology(${accountId}) failed`, e);
    }
  },

  // ── WEBSOCKET MERGE ─────────────────────────────────────────────────────
  // Called for every incoming WebSocket event

  mergeEvent: (event) => {
    const { type, data } = event;

    if (type === 'health_score_updated') {
      set(state => ({
        accounts: state.accounts.map(a =>
          a.accountId === data.accountId
            ? { ...a, score: data.score, calculatedAt: Date.now() }
            : a
        ),
      }));
    }

    if (type === 'health_scores_bulk') {
      const updated = data.scores || [];
      set(state => ({
        accounts: state.accounts.map(a => {
          const u = updated.find(s => s.accountId === a.accountId);
          return u ? { ...a, score: u.score } : a;
        }),
      }));
    }

    if (type === 'anomaly_detected') {
      set(state => ({
        anomalies: [data, ...state.anomalies].slice(0, 50),
      }));
    }

    if (type === 'incident_created' || type === 'incident_summary_ready') {
      // Refresh full incidents list to get latest AI summary
      api.getAllIncidents()
        .then(r => set({ incidents: r.incidents || [] }))
        .catch(() => {});
    }
  },

  // ── INIT ─────────────────────────────────────────────────────────────────

  init: () => {
    get().fetchAll();

    // Auto-refresh every 30 seconds
    const refreshInterval = setInterval(() => get().fetchAll(), 30_000);

    // WebSocket
    connectWebSocket();
    const unsub = subscribeToEvents((event) => get().mergeEvent(event));

    // Return cleanup
    return () => {
      clearInterval(refreshInterval);
      unsub();
    };
  },
}));
