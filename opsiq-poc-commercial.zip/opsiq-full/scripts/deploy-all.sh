#!/usr/bin/env bash
# opsiq-poc/scripts/deploy-all.sh
# Full POC deployment: central stacks then simulation stacks.
# Prerequisites: run bootstrap.sh first.
#
# Usage:
#   export AWS_PROFILE=your-govcloud-profile
#   export LAMBDA_CODE_BUCKET=opsiq-lambda-pkgs-<account-id>
#   export REGION=us-west-2
#   ./scripts/deploy-all.sh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

export PROJECT="${PROJECT:-opsiq}"
export REGION="${REGION:-us-west-2}"
export LAMBDA_CODE_BUCKET="${LAMBDA_CODE_BUCKET:?Run bootstrap.sh first and set LAMBDA_CODE_BUCKET}"

START_TIME=$(date +%s)

echo "╔══════════════════════════════════════════════════╗"
echo "║  OpsIQ POC — Full Deployment                    ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║  This will deploy 8 CloudFormation stacks:      ║"
echo "║    Central  : 6 stacks (storage → dashboard)    ║"
echo "║    Simulation: 2 stacks (seed + generators)     ║"
echo "║  Estimated time: 10–15 minutes                  ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# Deploy central
bash "$ROOT_DIR/central/scripts/deploy-central.sh"

echo ""
echo "══════════════════════════════════════════════════"
echo ""

# Deploy simulation
bash "$ROOT_DIR/simulation/scripts/deploy-simulation.sh"

END_TIME=$(date +%s)
ELAPSED=$(( END_TIME - START_TIME ))
MINUTES=$(( ELAPSED / 60 ))
SECONDS=$(( ELAPSED % 60 ))

echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║  Full POC Deployment Complete                   ║"
echo "║  Time: ${MINUTES}m ${SECONDS}s"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "Wait 2 minutes for generators to produce initial signals, then"
echo "open the Dashboard URL printed above."
echo ""
echo "To trigger a live demo:"
echo "  aws lambda invoke \\"
echo "    --function-name ${PROJECT}-sim-anomaly-injector \\"
echo "    --payload '{\"scenario\": \"ecs-oom\", \"accountId\": \"sim-app-a\"}' \\"
echo "    --region $REGION response.json && cat response.json"
